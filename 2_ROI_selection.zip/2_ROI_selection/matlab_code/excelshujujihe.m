clear all;
clc
for tt = 3
    for pp = 2
        if tt == 1 && pp == 1
            excel_path=  'G:\0622\vnir\';   %文件夹路径 
            excel_path3=  'G:\0622\';   %文件夹路径 
            i1 = 1;
            i2 = 50;
        end
        if tt == 1 && pp == 2
            excel_path=  'G:\0622\swir\';   %文件夹路径 
            excel_path3=  'G:\0622\';   %文件夹路径 
            i1 = 1;
            i2 = 50;
        end
        if tt == 2 && pp == 1
            excel_path=  'G:\0704\vnir\';   %文件夹路径 
            excel_path3=  'G:\0704\';   %文件夹路径 
            i1 = 1;
            i2 = 60;
        end
        if tt == 2 && pp == 2
            excel_path=  'G:\0704\swir\';   %文件夹路径 
            excel_path3=  'G:\0704\';   %文件夹路径 
            i1 = 1;
            i2 = 60;
        end
        if tt == 3 && pp == 1
            excel_path=  'G:\0705\vnir\';   %文件夹路径 
            excel_path3=  'G:\0705\';   %文件夹路径 
            i1 = 61;
            i2 = 150;
        end
        if tt == 3 && pp == 2
            excel_path=  'G:\0705\swir\';   %文件夹路径 
            excel_path3=  'G:\0705\';   %文件夹路径 
            i1 = 61;
            i2 = 105;
        end
        if tt == 4 && pp == 1
            excel_path=  'G:\0706\vnir\';   %文件夹路径 
            excel_path3=  'G:\0706\';   %文件夹路径 
            i1 = 151;
            i2 = 220;
        end
        if tt == 4 && pp == 2
            excel_path=  'G:\0706\swir\';   %文件夹路径 
            excel_path3=  'G:\0706\';   %文件夹路径 
            i1 = 151;
            i2 = 220;
        end        
        if tt == 5 && pp == 1
            excel_path=  'G:\0707\vnir\';   %文件夹路径 
            excel_path3=  'G:\0707\';   %文件夹路径 
            i1 = 221;
            i2 = 270;
        end
        if tt == 5 && pp == 2
            excel_path=  'G:\0707\swir\';   %文件夹路径 
            excel_path3=  'G:\0707\';   %文件夹路径 
            i1 = 221;
            i2 = 270;
        end
        if tt == 6 && pp == 1
            excel_path=  'G:\0710\vnir\';   %文件夹路径 
            excel_path3=  'G:\0710\';   %文件夹路径 
            i1 = 1;
            i2 = 50;
        end
        if tt == 6 && pp == 2
            excel_path=  'G:\0710\swir\';   %文件夹路径 
            excel_path3=  'G:\0710\';   %文件夹路径 
            i1 = 1;
            i2 = 50;
        end        
        
        shuju = [];
        for i = i1:i2
            for j = 1:2
                excel_path2 = [excel_path num2str(i) '-' num2str(j) '\Hyperspectral_data.xlsx'];
                shuju(j+(i-1)*2,:) = xlsread(excel_path2);
            end
        end

        excel_path4 = [excel_path3 'vnir.xlsx'];
        excel_path5 = [excel_path3 'swir.xlsx'];

        if pp == 1
            xlswrite(excel_path4, shuju);
        end
        if pp == 2
            xlswrite(excel_path5, shuju);
        end        
    end
end
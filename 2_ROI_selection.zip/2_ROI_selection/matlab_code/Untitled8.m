clear all;
clc


% 2、数据预览
b = xlsread("F:\Litchi\Indoor\Xian_jin_feng\2.xlsx");

b1 = b(:,80);
b2 = b(:,79);
b4 = b(:,81);
b3 = [];

i1 = 0;i2 = 0;i3 = 0;i4 = 0;
i5 = 0;i6 = 0;i7 = 0;i8 = 0;



for i =1:307
    if b2(i)<20 || b1(i)<17.0 || b4(i)<0.1 
        b3(i) = 3;
        i1 = i1+1;
    else
        if b2(i)<23 || b1(i)<18 || b4(i)<0.1 
            b3(i) = 2;
            i2 = i2+1;
        else
            if b2(i)>=23 || b1(i)>=18 || b4(i)>=0.1 
                b3(i) = 1;
                i3 = i3+1;
            end
        end
    end
end 

h = figure;
set(h,'position',[300 300 800 300]);
subplot(121)
s = 36;
scatter3(b1(1),b2(1),b4(1),s,'MarkerEdgeColor','k','MarkerFaceColor',[0 0.4470 0.7410]);hold on;
scatter3(b1(2),b2(2),b4(2),s,'MarkerEdgeColor','k','MarkerFaceColor',[0.8500 0.3250 0.0980]);hold on;
scatter3(b1(6),b2(6),b4(6),s,'MarkerEdgeColor','k','MarkerFaceColor',[0.9290 0.6940 0.1250]);hold on;

for i =1:307
    s = 36;
    if b3(i) == 1
        scatter3(b1(i),b2(i),b4(i),s,'MarkerEdgeColor','k','MarkerFaceColor',[0 0.4470 0.7410], 'LineWidth',1.2);hold on;
    end
    if b3(i) == 2
        scatter3(b1(i),b2(i),b4(i),s,'MarkerEdgeColor','k','MarkerFaceColor',[0.8500 0.3250 0.0980], 'LineWidth',1.2);hold on;
    end
    if b3(i) == 3
        scatter3(b1(i),b2(i),b4(i),s,'MarkerEdgeColor','k','MarkerFaceColor',[0.9290 0.6940 0.1250], 'LineWidth',1.2);hold on;
    end
end 

b3 = b3';


ax = set(gca,'FontSize',12,'Fontname', 'Arial', 'LineWidth',1.5, 'FontWeight', 'bold');
xlabel({'\fontname{Arial}SSC (%)'},'FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Weight (g)'},'FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
zlabel({'\fontname{Arial}AC (mg·g^{\fontsize{6}-1}·FW)'},'FontSize',12, 'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'XTick',15:1:21,'FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'YTick',10:5:40,'FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'ZTick',0:0.6:1.2,'FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');

xlim([15 21]); % 设置 x 轴范围
ylim([10 40]); % 设置 y 轴范围
zlim([0 1.2]); % 设置 z 轴范围
% 平面参数
%1
x_plane = [18, 21, 21, 18];
y_plane = [23, 23, 40, 40];
z_plane = ones(size(x_plane)) * 0.1; % z = 0 平面
% 添加带有透明度的平面
h = fill3(x_plane, y_plane, z_plane, 'b', 'LineWidth',1.5); % 用红色填充平面
alpha(h, 0.2); % 设置透明度为0.5
%2
x_plane = ones(size(z_plane)) * 18;
y_plane = [23, 40, 40, 23 ];
z_plane = [0.1, 0.1, 1.2, 1.2]; % z = 0 平面
% 添加带有透明度的平面
h = fill3(x_plane, y_plane, z_plane, 'b', 'LineWidth',1.5); % 用红色填充平面
alpha(h, 0.2); % 设置透明度为0.5
%3
x_plane = [18, 21, 21, 18];
y_plane = ones(size(z_plane)) * 23;
z_plane = [0.1, 0.1, 1.2, 1.2]; % z = 0 平面
% 添加带有透明度的平面
h = fill3(x_plane, y_plane, z_plane, 'b', 'LineWidth',1.5); % 用红色填充平面
alpha(h, 0.2); % 设置透明度为0.5


%1
x_plane = [17, 21, 21, 17];
y_plane = [20, 20, 40, 40];
z_plane = ones(size(x_plane)) * 0.099; % z = 0 平面
% 添加带有透明度的平面
h = fill3(x_plane, y_plane, z_plane, [0.9290 0.6940 0.1250], 'LineWidth',1.5); % 用红色填充平面
alpha(h, 0.2); % 设置透明度为0.5
%2
x_plane = ones(size(z_plane)) * 17;
y_plane = [20, 40, 40, 20 ];
z_plane = [0.1, 0.1, 1.2, 1.2]; % z = 0 平面
% 添加带有透明度的平面
h = fill3(x_plane, y_plane, z_plane, [0.9290 0.6940 0.1250], 'LineWidth',1.5); % 用红色填充平面
alpha(h, 0.2); % 设置透明度为0.5
%3
x_plane = [17, 21, 21, 17];
y_plane = ones(size(z_plane)) * 20;
z_plane = [0.1, 0.1, 1.2, 1.2]; % z = 0 平面
% 添加带有透明度的平面
h = fill3(x_plane, y_plane, z_plane, [0.9290 0.6940 0.1250], 'LineWidth',1.5); % 用红色填充平面
alpha(h, 0.2); % 设置透明度为0.5
view(30,78);

box on;
ax = gca;
ax.LineWidth = 1.5;
set(gca,'TickDir','in')



b = xlsread("F:\Litchi\Indoor\Xian_jin_feng\新建 Microsoft Excel 工作表.xlsx");
b3 = [];

for i = 1:62
    if b(i,1)<20 || b(i,2)<17 || b(i,4)<0.1 
        b3(i) = 3;
    else
        if b(i,1)<23 || b(i,2)<18 || b(i,4)<0.1 
            b3(i) = 2;
        else
            if b(i,1)>=23 || b(i,2)>=18 || b(i,4)>=0.1 
                b3(i) = 1;
            end
        end
    end
end

b3 = b3';


b4 = [];

for i = 1:62
    if b(i,1)<20 || b(i,3)<17 || b(i,5)<0.1 
        b4(i) = 3;
    else
        if b(i,1)<23 || b(i,3)<18 || b(i,5)<0.1 
            b4(i) = 2;
        else
            if b(i,1)>=23 || b(i,3)>=18 || b(i,5)>=0.1 
                b4(i) = 1;
            end
        end
    end
end

b4 = b4';
subplot(122)
[mat,order] = confusionmat(b4, b3);
 % 使用 flipud 函数上下翻转矩阵
mat = flipud(mat);
 %mat = rand(10);           %# A 5-by-5 matrix of random values from 0 to 1
% mat(3,3) = 0;            %# To illustrate
% mat(5,2) = 0;            %# To illustrate
imagesc(mat);            %# Create a colored plot of the matrix values
colormap(flipud(gray));  %# Change the colormap to gray (so higher values are
                         %#   black and lower values are white)
 
textStrings = num2str(mat(:));  %# Create strings from the matrix values
textStrings = strtrim(cellstr(textStrings));  %# Remove any space padding
 
[x,y] = meshgrid(1:3);   %# Create x and y coordinates for the strings
hStrings = text(x(:),y(:),textStrings(:),...      %# Plot the strings
                'HorizontalAlignment','center', 'FontWeight', 'bold');
midValue = mean(get(gca,'CLim'));  %# Get the middle value of the color range
textColors = repmat(mat(:) > midValue,1,3);  %# Choose white or black for the
                                             %#   text color of the strings so
                                             %#   they can be easily seen over
                                             %#   the background color
set(hStrings,{'Color'},num2cell(textColors,2),'FontSize',12,'Fontname', 'Arial');  %# Change the text colors
 
set(gca,'XTick',1:3,...                         %# Change the axes tick marks
        'XTickLabel',{'Grade 1','Grade 2','Grade 3'},...  %#   and tick labels
        'YTick',1:3,...
        'YTickLabel',{'Grade 3','Grade 2','Grade 1'},...
        'TickLength',[0 0],'FontSize',12,'Fontname', 'Arial', 'LineWidth',1.5, 'FontWeight', 'bold');
ytickangle(90);
xlabel('Actual Grade','FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold');
ylabel('Predicted Grade','FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold');


clear all;
clc

for tt = 3
    for pp = 2
        if tt == 1 && pp == 1
            excel_path=  'G:\0622\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0622\swir.xlsx';   %文件夹路径
            excel_path2=  'G:\0622\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0622\swir2.xlsx';   %文件夹路径  
            
        end
        if tt == 1 && pp == 2
            excel_path=  'G:\0622\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0622\swir.xlsx';   %文件夹路径
            excel_path2=  'G:\0622\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0622\swir2.xlsx';   %文件夹路径 
        end
        if tt == 2 && pp == 1
            excel_path=  'G:\0704\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0704\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0704\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0704\swir2.xlsx';   %文件夹路径 
        end
        if tt == 2 && pp == 2
            excel_path=  'G:\0704\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0704\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0704\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0704\swir2.xlsx';   %文件夹路径 
        end
        if tt == 3 && pp == 1
            excel_path=  'G:\0705\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0705\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0705\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0705\swir2.xlsx';   %文件夹路径 
        end
        if tt == 3 && pp == 2
            excel_path=  'G:\0705\swir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0705\swir3.xlsx';   %文件夹路径 
            excel_path2=  'G:\0705\swir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0705\swir4.xlsx';   %文件夹路径 
        end
        if tt == 4 && pp == 1
            excel_path=  'G:\0706\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0706\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0706\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0706\swir2.xlsx';   %文件夹路径 
        end
        if tt == 4 && pp == 2
            excel_path=  'G:\0706\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0706\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0706\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0706\swir2.xlsx';   %文件夹路径 
        end        
        if tt == 5 && pp == 1
            excel_path=  'G:\0707\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0707\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0707\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0707\swir2.xlsx';   %文件夹路径 
        end
        if tt == 5 && pp == 2
            excel_path=  'G:\0707\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0707\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0707\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0707\swir2.xlsx';   %文件夹路径 
        end
        if tt == 6 && pp == 1
            excel_path=  'G:\0710\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0710\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0710\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0710\swir2.xlsx';   %文件夹路径 
        end
        if tt == 6 && pp == 2
            excel_path=  'G:\0710\vnir.xlsx';   %文件夹路径 
            excel_path3=  'G:\0710\swir.xlsx';   %文件夹路径 
            excel_path2=  'G:\0710\vnir2.xlsx';   %文件夹路径 
            excel_path4=  'G:\0710\swir2.xlsx';   %文件夹路径 
        end    
        
        shuju = [];
        shuju3 = [];
        shuju = xlsread(excel_path);
        r1 = size(shuju,1); %返回的时数组A的行数
        
        for i = 1:(r1-1)
            shuju3(round((i+1)/2),:) = mean(shuju(i:(i+1),:));
        end
            
        shuju2 = [];
        shuju4 = [];
        shuju2 = xlsread(excel_path3);
        r2 = size(shuju2,1); %返回的时数组A的行数
        
        for i = 1:(r2-1)
            shuju4(round((i+1)/2),:) = mean(shuju2(i:(i+1),:));
        end
        
        xlswrite(excel_path2, shuju3);
        xlswrite(excel_path4, shuju4);
        
    end
end


clear all;
clc
CC = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\4_化学含量数据\weight.xlsx');
CC1 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\4_化学含量数据\tangdu.xlsx');
CC2 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\4_化学含量数据\suandu.xlsx');
CC4 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\4_化学含量数据\hua.xlsx');
% C = TheColor('hunt',189);
% % C = TheColor('hunt',203);
% % C = TheColor('hunt',603);
% C1 = C(2,:);

xx = ones(104,1);
xx2 = ones(104,1)*2;
xx3 = ones(104,1)*3;
X1=CC(1:104,1);
X2=CC(106:209,1);
X3=CC(212:315,1);
data = [X1,X2,X3];
newColorList=[244,111,68;127,203,164;75,101,175]./255;
C = TheColor('hunt',189);
% C = TheColor('hunt',203);
% C = TheColor('hunt',603);
C1 = C(1,:);
C2 = C(2,:);
C3 = C(3,:);
C4 = C(4,:);

% 图片尺寸设置（单位：厘米）
h = figure;
set(h,'position',[100 100 800 300]);

% 小提琴图绘制
subplot(131)
h_rect = patch([-2 -2 -3 -3], [-2 -2 -3 -3], 'w');hold on;  % 手动绘制一个红色长方形
set(h_rect, 'EdgeColor', 'k', 'LineWidth', 1.5);  % 黑色边框，线宽为 5
plot(nan, nan, '|', 'MarkerSize', 10, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'none', 'LineWidth', 1.5);hold on;
plot(nan, nan, 'd', 'MarkerSize', 6, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'k');hold on;
plot(nan, nan, 'o', 'MarkerSize', 6, 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r');hold on;

h = violin(data,'x',1:3,...      % x坐标刻度
            'facecolor','w', ...          % 面颜色
            'edgecolor','k',...         % 轮廓颜色
            'facealpha',0.8,...         % 透明度
            'bw',1.2,...                % 核函数带宽Kernel bandwidth
            'mc',[],...                 % 平均值线颜色
            'medc',[]);                % 中位数线颜色
set(h,'Linewidth',1.5,'LineStyle','-');

ms = 12;
s1 = swarmchart(xx,X1,ms,newColorList(1,:),'filled');
s2 = swarmchart(xx2,X2,ms,newColorList(2,:),'filled');
s3 = swarmchart(xx3,X3,ms,newColorList(3,:),'filled');

xjs = 0.55;
set(s1,'XJitterWidth',xjs)
set(s2,'XJitterWidth',xjs)
set(s3,'XJitterWidth',xjs)

hold on;
hXLabel = xlabel('Species');
hYLabel = ylabel('Weight (g)');

% 绘制箱线图
h = boxplot(data,'Colors','k','Symbol','','Widths',0.12);hold on;
ert1 = median(data,1);
scatter(1,ert1(1),49,C(1,:),'diamond','filled');hold on;
scatter(2,ert1(2),49,C(1,:),'diamond','filled');hold on;
scatter(3,ert1(3),49,C(1,:),'diamond','filled');hold on;
set(h,'Linewidth',1.5,'LineStyle','-');
set(gca, 'Box', 'off', ...                                        % 边框
         'LineWidth',1.5,...                                        % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.005 .005], ...         % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1],...          % 坐标轴颜色
         'XTick', 1:3,...                                         % 坐标区刻度、范围
         'Xticklabels',{'FZX ','GW ','NMC '},...
         'XLim', [0.5 3.5],...
         'YLim',[10 50])
set(gca, 'FontName', 'Arial', 'FontSize', 12,'FontWeight', 'bold')
set([hXLabel, hYLabel], 'FontSize', 12, 'FontName', 'Arial','FontWeight', 'bold')
leg = legend({'25%-75%', '1.5IQR','Median', 'Outliers'}, 'Location', 'northwest');
leg.ItemTokenSize = [15,20];


% 背景颜色
set(gcf,'Color',[1 1 1])
% 添加上、右框线
xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
           'Position',get(gca,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor',xc,...
           'YColor',yc);
set(ax, 'linewidth',1.5,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.005 .005], ...         % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1],...          % 坐标轴颜色
         'XTick', 1:3,...                                         % 坐标区刻度、范围
         'Xticklabels',{' ',' ',' '},...
         'XLim', [0.5 3.5],...
         'YLim',[10 40],...                                         % 坐标区刻度、范围
         'Yticklabels',{' ',' ',' ',' ',' ',' ',' ',' ',' '})



X1=CC1(1:104,1)+1.7;
X2=CC1(106:209,1)+1.7;
X3=CC1(211:314,1)+1.7;
data = [X1,X2,X3];
% % 小提琴图绘制
subplot(132)

h = violin(data,'x',1:3,...      % x坐标刻度
            'facecolor','w', ...          % 面颜色
            'edgecolor','k',...         % 轮廓颜色
            'facealpha',0.8,...         % 透明度
            'bw',1,...                % 核函数带宽Kernel bandwidth
            'mc',[],...                 % 平均值线颜色
            'medc',[]);                % 中位数线颜色
set(h,'Linewidth',1.5,'LineStyle','-');

ms = 12;
s1 = swarmchart(xx,X1,ms,newColorList(1,:),'filled');
s2 = swarmchart(xx2,X2,ms,newColorList(2,:),'filled');
s3 = swarmchart(xx3,X3,ms,newColorList(3,:),'filled');

xjs = 0.55;
set(s1,'XJitterWidth',xjs)
set(s2,'XJitterWidth',xjs)
set(s3,'XJitterWidth',xjs)

hold on;
hXLabel = xlabel('Species','FontWeight', 'bold');
hYLabel = ylabel('SSC (%)','FontWeight', 'bold');

% 绘制箱线图
h = boxplot(data,'Colors','k','Symbol','','Widths',0.12);hold on;
ert1 = median(data,1);
scatter(1,ert1(1),49,C(1,:),'diamond','filled');hold on;
scatter(2,ert1(2),49,C(1,:),'diamond','filled');hold on;
scatter(3,ert1(3),49,C(1,:),'diamond','filled');hold on;

set(h,'Linewidth',1.5,'LineStyle','-');
set(gca, 'Box', 'off', ...                                        % 边框
         'LineWidth',1.5,...                                        % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.005 .005], ...         % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1],...          % 坐标轴颜色
         'XTick', 1:3,...                                         % 坐标区刻度、范围
         'Xticklabels',{'FZX ','GW ','NMC '},...
         'XLim', [0.5 3.5],...
         'YLim',[10 24])
set(gca, 'FontName', 'Arial', 'FontSize', 12,'FontWeight', 'bold')
set([hXLabel, hYLabel], 'FontSize', 12, 'FontName', 'Arial','FontWeight', 'bold')
% 背景颜色
set(gcf,'Color',[1 1 1])
% 添加上、右框线
xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
           'Position',get(gca,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor',xc,...
           'YColor',yc);
set(ax, 'linewidth',1.5,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.005 .005], ...         % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1],...          % 坐标轴颜色
         'XTick', 1:3,...                                         % 坐标区刻度、范围
         'Xticklabels',{' ',' ',' '},...
         'XLim', [0.5 3.5],...
         'YLim',[10 40],...                                         % 坐标区刻度、范围
         'Yticklabels',{' ',' ',' ',' ',' ',' ',' ',' ',' '})

     
     
     
xx = ones(103,1);
xx2 = ones(103,1)*2;
xx3 = ones(103,1)*3;
X1=CC4(1:103,1);
X2=CC4(105:207,1);
X3=CC4(211:313,1);
data = [X1,X2,X3];
% 小提琴图绘制
subplot(133)

h = violin(data,'x',1:3,...      % x坐标刻度
            'facecolor','w', ...          % 面颜色
            'edgecolor','k',...         % 轮廓颜色
            'facealpha',0.8,...         % 透明度
            'bw',0.05,...                % 核函数带宽Kernel bandwidth
            'mc',[],...                 % 平均值线颜色
            'medc',[]);                % 中位数线颜色
set(h,'Linewidth',1.5,'LineStyle','-');

ms = 12;
s1 = swarmchart(xx,X1,ms,newColorList(1,:),'filled');
s2 = swarmchart(xx2,X2,ms,newColorList(2,:),'filled');
s3 = swarmchart(xx3,X3,ms,newColorList(3,:),'filled');

xjs = 0.55;
set(s1,'XJitterWidth',xjs)
set(s2,'XJitterWidth',xjs)
set(s3,'XJitterWidth',xjs)

hold on;
hXLabel = xlabel('Species','FontWeight', 'bold');
hYLabel = ylabel('AC (mg·g^-^1·FW)','FontWeight', 'bold');

% 绘制箱线图
h = boxplot(data,'Colors','k','Symbol','','Widths',0.12,'MedianStyle','target');hold on;
% 查找离群点
h2 = findobj(gcf, 'tag', 'Outliers');  % 获取离群点对象的句柄

% 设置离群点颜色为红色
for i = 1:length(h2)
    set(h2(i), 'Marker', 'o', 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r', 'MarkerSize', 4);  % 设置颜色
end

ert1 = median(data,1);
scatter(1,ert1(1),49,C(1,:),'diamond','filled');hold on;
scatter(2,ert1(2),49,C(1,:),'diamond','filled');hold on;
scatter(3,ert1(3),49,C(1,:),'diamond','filled');hold on;

set(h,'Linewidth',1.5,'LineStyle','-');
set(gca, 'Box', 'off', ...                                        % 边框
         'LineWidth',1.5,...                                        % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.005 .005], ...         % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1],...          % 坐标轴颜色
         'XTick', 1:3,... 
         'YTick', -0.2:0.2:1.4,...% 坐标区刻度、范围
         'Xticklabels',{'FZX ','GW ','NMC '},...
         'XLim', [0.5 3.5],...
         'YLim',[-0.2 1.4])
set(gca, 'FontName', 'Arial', 'FontSize', 12,'FontWeight', 'bold')
set([hXLabel, hYLabel], 'FontSize', 12, 'FontName', 'Arial','FontWeight', 'bold')
% 背景颜色
set(gcf,'Color',[1 1 1])
% 添加上、右框线
xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
           'Position',get(gca,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor',xc,...
           'YColor',yc);
set(ax, 'linewidth',1.5,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.005 .005], ...         % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1],...          % 坐标轴颜色
         'XTick', 1:3,...                                         % 坐标区刻度、范围
         'Xticklabels',{' ',' ',' '},...
         'XLim', [0.5 3.5],...
         'YLim',[10 40],...                                         % 坐标区刻度、范围
         'Yticklabels',{' ',' ',' ',' ',' ',' ',' ',' ',' '})

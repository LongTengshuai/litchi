clear all;
clc
sd = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_original_spectra_and_spectral_extraction\3_Origin_trans_spectra\VNIR_SWIR_R.xlsx');

x1 = sd(1,2:119);
x2 = sd(1,120:181);
x3 = sd(1,2:181);

y1 = sd(3:377,2:119);
y2 = sd(3:377,120:181);
y3(:,1:118) = sd(3:377,2:119);
y3(:,119:180) = 0.55*sd(3:377,120:181);

% h = figure;
% set(h,'position',[100 100 600 300]);
% 
% plot(x1,y1,'LineWidth',1.2);hold on;
% plot(x2,y2*0.55,'LineWidth',1.2);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% ylabel({'\fontname{Arial}Ratio'},'FontSize',12);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.2);
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% 
% axis([500 1200 -1 8]);
% % 添加局部放大
% zp = BaseZoom();
% zp.plot;



h = figure;
set(h,'position',[100 100 600 300]);

plot(x3,y3,'LineWidth',1.2);hold on;
xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
ylabel({'\fontname{Arial}Ratio'},'FontSize',12);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.2);
set(gca,'TickDir','in')
set(gca, 'Box', 'on');
axis([500 1200 -1 8]);

% 添加局部放大
zp = BaseZoom();
zp.plot;
clear all;
clc

a1 = imread('F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230622\VNIR\1-1.raw\图片1.png');
a2 = imread('F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230622\VNIR\1-1.raw\2.bmp');


for i =1:162
    for j =1:198
        if a2(i,j) == 0
            a1(i,j,1) = 0;
            a1(i,j,2) = 0;
            a1(i,j,3) = 0;
        end
    end
end


alpha=ones(162,198);
alpha(a2==0)=0;    %取背景部分0 0为透明
imwrite(a1,'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230622\VNIR\1-1.raw\1.png','Alpha',alpha)


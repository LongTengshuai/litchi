% clear all;
% clc

newColorList=[244,111,68;127,203,164;75,101,175]./255;
% 2������Ԥ��
b = xlsread("F:\Litchi\Indoor\Xian_jin_feng\5_texture_features\VNIR_SWIR_R_G_ALL.xlsx");
x = b(1,2:181);
b1_1 = b(3:106,2:181);
b1_2 = b(108:210,2:181);
b1_3 = b(212:315,2:181);
b1 = [b1_1; b1_2;b1_3];
% b1 = b(:,1:180);
% ��һ��
A1=mapminmax(b1(:,1:180),0.005,1);

% % һ�׵�
A3=diff(b1');A3=A3';

% MSC
bb=mean(b1);
A6=msc(b1,bb);

% % һ�׵�
A7=diff(A1');A7=A7';

% MSC
bb2=mean(A1);
A8=msc(A1,bb2);

% str1 = {'\fontname{Arial}A'};
% str2 = {'\fontname{Arial}B'};
% str3 = {'\fontname{Arial}C'};
% str4 = {'\fontname{Arial}D'};
% 

% h = figure;
% set(h,'position',[100 100 400 350]);
% plot([1,1],[2,2],'color',newColorList(1,:),'LineWidth',6);hold on;
% plot([1,1],[2,2],'color',newColorList(2,:),'LineWidth',6);hold on;
% plot([1,1],[2,2],'color',newColorList(3,:),'LineWidth',6);hold on;
% plot(x,mean(b1_1),'color',newColorList(1,:),'LineWidth',1.5);hold on;
% plot(x,mean(b1_2),'color',newColorList(2,:),'LineWidth',1.5);hold on;
% plot(x,mean(b1_3),'color',newColorList(3,:),'LineWidth',1.5);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% ylabel({'\fontname{Arial}Reflectance'},'FontSize',12);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.2);
% set(gca,'TickDir','in')
% axis([500 1200 0 6]);
% leg = legend('\fontname{Arial}XJF-FZX','\fontname{Arial}XJF-GW','\fontname{Arial}XJF-NMC','Location','northwest','LineWidth',1.2);
% leg.ItemTokenSize = [15,40];

h = figure;
set(h,'position',[100 100 370 570]);
subplot(311)
plot(x,b1/10,'LineWidth',1.5);hold on;
xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
xticks(500:200:1300);
ylabel({'\fontname{Arial}Transmittance'},'FontSize',12);
yticks(0:0.2:0.8);
set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
set(gca,'TickDir','in')
set(gca, 'FontWeight', 'bold');
axis([500 1300 0 0.8]);



subplot(312)
sd = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_ԭʼ���������Լ�������ȡ\3_����������\VNIR_SWIR_R.xlsx');

dq=jet(351); 
for i = 351:-1:1
    QWER2 = A12(i,:);
    plot(x3,QWER2,'color',dq(round(351*A_no_nan_cols_map2(i)),:),'LineWidth',1.5);hold on;
end
xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Norm'},'FontSize',12, 'FontWeight', 'bold');
xticks(500:200:1300);
yticks(0:0.2:1);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on');
axis([500 1300 -0.005 1]);


% subplot(2,3,2)
% plot(x,mean(A1(1:104,:)),'color',newColorList(1,:),'LineWidth',1.2);hold on;
% plot(x,mean(A1(105:207,:)),'color',newColorList(2,:),'LineWidth',1.2);hold on;
% plot(x,mean(A1(208:311,:)),'color',newColorList(3,:),'LineWidth',1.2);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% ylabel({'\fontname{Arial}Rs-NRM'},'FontSize',12);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.2);
% set(gca,'TickDir','in')
% axis([500 1200 0 1]);
% % title('\fontname{Arial}Normalization','LineWidth',1.2);
% 
% 
% subplot(2,3,3)
% plot(x,mean(A6(1:104,:)),'color',newColorList(1,:),'LineWidth',1.2);hold on;
% plot(x,mean(A6(105:207,:)),'color',newColorList(2,:),'LineWidth',1.2);hold on;
% plot(x,mean(A6(208:311,:)),'color',newColorList(3,:),'LineWidth',1.2);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% ylabel({'\fontname{Arial}Rs-MSC'},'FontSize',12);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.2);
% set(gca,'TickDir','in')
% axis([500 1200 0 6]);
% % title('\fontname{Arial}MSC','LineWidth',1.2);
% 
% 
% subplot(2,3,4)
% plot(x(1:179),mean(A3(1:104,:)),'color',newColorList(1,:),'LineWidth',1.2);hold on;
% plot(x(1:179),mean(A3(105:207,:)),'color',newColorList(2,:),'LineWidth',1.2);hold on;
% plot(x(1:179),mean(A3(208:311,:)),'color',newColorList(3,:),'LineWidth',1.2);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% ylabel({'\fontname{Arial}Rs-FD'},'FontSize',12);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.2);
% set(gca,'TickDir','in')
% axis([500 1200 -0.4 0.4]);
% % title('\fontname{Arial}FD','LineWidth',1.2);
% 
% subplot(2,3,5)
% plot(x(1:179),mean(A7(1:104,:)),'color',newColorList(1,:),'LineWidth',1.2);hold on;
% plot(x(1:179),mean(A7(105:207,:)),'color',newColorList(2,:),'LineWidth',1.2);hold on;
% plot(x(1:179),mean(A7(208:311,:)),'color',newColorList(3,:),'LineWidth',1.2);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% ylabel({'\fontname{Arial}Rs-NRM-FD'},'FontSize',12);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.2);
% set(gca,'TickDir','in')
% axis([500 1200 -0.1 0.1]);
% % title('\fontname{Arial}FD','LineWidth',1.2);

ern = [2,7,10,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112,120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
wert = mean(A8(1:104,:));

subplot(313)
plot(x,wert,'k','LineWidth',1.5);hold on;
scatter(x(ern),wert(ern),9,'r','filled');hold on;
scatter(0,1,9,'k','filled');hold on;
% plot(x,mean(A8(105:207,:)),'color',newColorList(2,:),'LineWidth',1.2);hold on;
% plot(x,mean(A8(208:311,:)),'color',newColorList(3,:),'LineWidth',1.2);hold on;
xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
xticks(500:200:1300);
ylabel({'\fontname{Arial}Norm-MSC'},'FontSize',12);
yticks(0:0.3:1.2);
set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
set(gca,'TickDir','in')
set(gca, 'FontWeight', 'bold');
axis([500 1300 0 1.2]);
leg = legend({'Norm-MSC','Selected','bands'},'fontname','Arial','Location','northeast','LineWidth',1.5);
leg.ItemTokenSize = [15,40];




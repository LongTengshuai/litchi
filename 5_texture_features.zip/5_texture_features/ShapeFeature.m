function T = ShapeFeature(path)
% 长度（荔枝最小外接矩形的长）；
% 宽度（荔枝最小外接矩形的宽）；
% 周长（荔枝边缘上所有像素数之和）；
% 面积（荔枝区域内所有像素和）；
% 长轴长（与荔枝区域具有相同标准二阶中心矩的椭圆的长轴长度（像素意义下））；
% 短轴长（与荔枝区域具有相同标准二阶中心矩的椭圆的短轴长度（像素意义下））；
% 离心率（与区域具有相同标准二阶中心矩的椭圆的离心率）；
% 紧密度（荔枝面积与荔枝最小外接矩形面积的比值）；
% 长短轴比（荔枝长轴长与短轴长的比值）；
% 外观比（荔枝最小外接矩形的长宽比值）；
% 最小外接矩形面积（荔枝最小外接矩形的面积＝长度×宽度）。

I=imread(path); %此处为图像所放路径和图片名字。
bw=im2bw(I);         %将图像二值化
stats = regionprops(bw,'all');

[r,c]=find(bw==1);   
[rectx,recty,area,perimeter] = minboundrect(c,r,'a'); % 'a'是按面积算的最小矩形，如果按边长用'p'。
w=sqrt((rectx(1)-rectx(4))^2 + (recty(1)-recty(4))^2);
h=sqrt((rectx(1)-rectx(2))^2 + (recty(1)-recty(2))^2);
ty = 0;

if w<=h
    ty = h;
    h = w;
    w = ty;
end

j=(stats.Area) /(w*h);
b1=stats.MajorAxisLength/stats.MinorAxisLength;
b2=w./h;
b3=w*h;

T = [w;h;stats.Perimeter;stats.Area;stats.MajorAxisLength;stats.MinorAxisLength;stats.Eccentricity;j;b1;b2;b3];





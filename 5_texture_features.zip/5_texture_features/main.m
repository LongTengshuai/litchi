clear all;
clc
for ts = 6
    for pp = 2
        if ts == 1 && pp == 1
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230622\VNIR\';
            i1 = 1;
            i2 = 50;

        end
        if ts == 1 && pp == 2
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230622\SWIR\';
            i1 = 1;
            i2 = 50;

        end
        if ts == 2 && pp == 1
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230704\VNIR\';
            i1 = 1;
            i2 = 60;

        end
        if ts == 2 && pp == 2
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230704\SWIR\';
            i1 = 1;
            i2 = 60;

        end
        if ts == 3 && pp == 1
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230705\VNIR\';
            i1 = 61;
            i2 = 150;
   
        end
        if ts == 3 && pp == 2
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230705\SWIR\';
            i1 = 112;
            i2 = 150;

        end
        if ts == 4 && pp == 1
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230706\VNIR\';
            i1 = 151;
            i2 = 220;

        end
        if ts == 4 && pp == 2
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230706\SWIR\';
            i1 = 151;
            i2 = 220;

        end        
        if ts == 5 && pp == 1
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230707\VNIR\';
            i1 = 221;
            i2 = 270;

        end
        if ts == 5 && pp == 2
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230707\SWIR\';
            i1 = 221;
            i2 = 270;

        end
        if ts == 6 && pp == 1
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230710\VNIR\';
            i1 = 1;
            i2 = 50;

        end
        if ts == 6 && pp == 2
            path0 = 'F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230710\SWIR\';
            i1 = 1;
            i2 = 50;

        end   

        for i = i1:i2
            for j = 1:2
                path1 = [path0 num2str(i) '-' num2str(j) '.raw\4.bmp'];
                path2 = [path0 num2str(i) '-' num2str(j) '.raw\3.bmp'];
                path3 = [path0 num2str(i) '-' num2str(j) '.raw\2.bmp'];

                T1((i-i1)*2+j,:) = GLCMatrice(path1);
                T2((i-i1)*2+j,:) = GGCMatrice(path1);
                T3((i-i1)*2+j,:) = CDTMatrice(path1);
                T4((i-i1)*2+j,:) = colorMoments(path2);
                T5((i-i1)*2+j,:) = ShapeFeature(path3);

            end
            T11((i-i1+1),:) = mean(T1(((i-i1)*2+1):((i-i1)*2+2),:));
            T21((i-i1+1),:) = mean(T2(((i-i1)*2+1):((i-i1)*2+2),:));
            T31((i-i1+1),:) = mean(T3(((i-i1)*2+1):((i-i1)*2+2),:));
            T41((i-i1+1),:) = mean(T4(((i-i1)*2+1):((i-i1)*2+2),:));
            T51((i-i1+1),:) = mean(T5(((i-i1)*2+1):((i-i1)*2+2),:));         
            
            
        end
    end
end
function T = CDTMatrice(path)
%ʹ��ʮ�ֶԽ����������������ʶ��
myImage = imread(path,'bmp');
myGray = im2uint8(myImage); 

[M,N] =size(myGray);
CTU_DTU = zeros(81,81);
%CTU = zeros(400,400);
%DTU = zeros(400,400);

for i = 2:(M-1)
    for j = 2:(N-1)
        if myGray(i,j) > myGray(i-1,j)
            CTU1 = 0;
        else
            if myGray(i,j) == myGray(i-1,j)
                CTU1 = 1;
            else
                CTU1 = 2;
            end
        end
        
        if myGray(i,j) > myGray(i,j+1)
            CTU2 = 0;
        else
            if myGray(i,j) == myGray(i,j+1)
                CTU2 = 1;
            else
                CTU2 = 2;
            end
        end
        
        if myGray(i,j) > myGray(i+1,j)
            CTU3 = 0;
        else
            if myGray(i,j) == myGray(i+1,j)
                CTU3 = 1;
            else
                CTU3 = 2;
            end
        end
        
        if myGray(i,j) > myGray(i,j-1)
            CTU4 = 0;
        else
            if myGray(i,j) == myGray(i,j-1)
                CTU4 = 1;
            else
                CTU4 = 2;
            end
        end
        
        CTU = CTU1 * 1 + CTU2 * 3 + CTU3 * 9 + CTU4 * 27;
        
        if myGray(i,j) > myGray(i-1,j-1)
            DTU1 = 0;
        else
            if myGray(i,j) == myGray(i-1,j-1)
                DTU1 = 1;
            else
                DTU1 = 2;
            end
        end
        
        if myGray(i,j) > myGray(i-1,j+1)
            DTU2 = 0;
        else
            if myGray(i,j) == myGray(i-1,j+1)
                DTU2 = 1;
            else
                DTU2 = 2;
            end
        end
        
        if myGray(i,j) > myGray(i+1,j+1)
            DTU3 = 0;
        else
            if myGray(i,j) == myGray(i+1,j+1)
                DTU3 = 1;
            else
                DTU3 = 2;
            end
        end
        
        if myGray(i,j) > myGray(i+1,j-1)
            DTU4 = 0;
        else
            if myGray(i,j) == myGray(i+1,j-1)
                DTU4 = 1;
            else
                DTU4 = 2;
            end
        end
        
        DTU = DTU1 * 1 + DTU2 * 3 + DTU3 * 9 + DTU4 * 27;
        
        CTU_DTU(CTU+1,DTU+1) = CTU_DTU(CTU+1,DTU+1) + 1;
    end
end

sumT01 = 0.0;
sumT02 = 0.0;
sumT03 = 0.0;
sumT04 = 0.0;
sumT05 = 0.0;
sumT06 = 0.0;
sumT07 = 0.0;
sumT08 = 0.0;

for i = 1:81
    for j = 1:81
        sumT01 = sumT01 + CTU_DTU(i,j) / (1+(i-j).^2);
        sumT03 = sumT03 + CTU_DTU(i,j) * CTU_DTU(i,j);
        sumT04 = sumT04 + i * CTU_DTU(i,j);
        sumT05 = sumT05 + j * CTU_DTU(i,j);
        sumT06 = sumT06 + i * j * CTU_DTU(i,j);
        
        if CTU_DTU(i,j) == 0
            continue;
        end
        sumT02 = sumT02 + CTU_DTU(i,j) * log10(CTU_DTU(i,j));
    end
end

T1 = sumT01;%����

T2 = -sumT02;%��

T3 = sumT03;%���׾�/����

for i = 1:81
    for j = 1:81
        sumT07 = sumT07 + ((i - sumT04).^2) * CTU_DTU(i,j);
        sumT08 = sumT08 + ((j - sumT05).^2) * CTU_DTU(i,j);
    end
end

T4 = (sumT06 - sumT04 * sumT05) / (sumT07 *sumT08);%�����

T = [T1;T2;T3;T4];






function T = GGCMatrice(path)
%   GGCMatrix Program

myImage = imread(path,'bmp');
GrayA = im2uint8(myImage); 

[M,N] =size(GrayA);
GradientA = GrayA;

GradientMax = -255*4;
GradientMin = 4*255;

for i = 2:(M-1)
    for j = 2:(N-1)
        GradientA(i,j) = 4*GrayA(i,j) - GrayA(i-1,j) - GrayA(i+1,j) - GrayA(i,j-1) -GrayA(i,j+1);
        if GradientA(i,j)>GradientMax
            GradientMax = GradientA(i,j);
        end
        if GradientA(i,j)<GradientMin
            GradientMin = GradientA(i,j);
        end
    end
end

 GradientA = floor(GradientA * 64 / GradientMax) + 1;

for i = 1:M
    GradientA(1,i) = 0;
    GradientA(M,i) = 0;
    GradientA(i,1) = 0;
    GradientA(i,N) = 0;
end

 m = max(max(GrayA)); 
 GrayA = floor(GrayA * 64 / m) + 1;

 GGCMatrix = zeros(64,64);

 count = 0.0;
for i = 1:M
    for j = 1:N
        p = GrayA(i,j);
        q = GradientA(i,j);
        GGCMatrix(p+1,q+1) = GGCMatrix(p+1,q+1) + 1;
        count = count + 1;
    end
end

GGCMatrix = GGCMatrix / count;

sumT01 = 0.0; 
sumT02 = 0.0;
sumT03 = 0.0;
sumT04 = 0.0;
sumT05 = 0.0;
sumT06 = 0.0;
sumT07 = 0.0;
sumT08 = 0.0;
sumT09 = 0.0;

for i = 1:64
    for j = 1:64
        sumT01 = sumT01 + GGCMatrix(i,j)/((j+1)^2);
        sumT02 = sumT02 + (GGCMatrix(i,j))^2;
        sumT07 = sumT07 + (GGCMatrix(j,i))^2;
        sumT08 = sumT08 + (GGCMatrix(i,j))^2;
        sumT06 = sumT06 + GGCMatrix(i,j) / (1 + (i - j)^2);
        if GGCMatrix(i,j) == 0
            continue;
        end
        sumT09 = sumT09 + GGCMatrix(i,j) * log10(GGCMatrix(i,j));
    end
    sumT03 = sumT03 + i * ((sumT08)^2);
    sumT04 = sumT04 + i * ((sumT07)^2);
    sumT08 = 0.0;
    sumT07 = 0.0;
end

T1 = sumT01 / sumT02; %С�ݶ�����

T2 = sumT02; %���� 

for i = 1:64
    for j = 1:64
        sumT05 = sumT05 + (i - sumT03) * (j - sumT04) * GGCMatrix(i,j);
    end
end

T3 = sumT05; %�����

T4 = sumT06; %����

T5 = -sumT09; %�����

T = [T1;T2;T3;T4;T5];














clear all;
clc
myImage = imread('F:\Litchi\Indoor\Xian_jin_feng\论文\图片11-2.tif');

I = im2uint8(myImage(:,:,1));  

glcm1 = graycomatrix(I,'Offset',[0 1],'NumLevels',256);        %求图1的四个共生矩阵
glcm2 = graycomatrix(I,'Offset',[-1 1],'NumLevels',256);
glcm3 = graycomatrix(I,'Offset',[-1 0],'NumLevels',256);
glcm4 = graycomatrix(I,'Offset',[-1 -1],'NumLevels',256);

prpt1 = graycoprops(glcm1,{'contrast','homogeneity','correlation','energy'});   %求图1的四个特征向量
prpt2 = graycoprops(glcm2,{'contrast','homogeneity','correlation','energy'});
prpt3 = graycoprops(glcm3,{'contrast','homogeneity','correlation','energy'});
prpt4 = graycoprops(glcm4,{'contrast','homogeneity','correlation','energy'});

figure
subplot(221)
imshow(glcm1);
imwrite(glcm1,'F:\Litchi\Indoor\Xian_jin_feng\论文\1.tif');
subplot(222)
imshow(glcm2)
imwrite(glcm2,'F:\Litchi\Indoor\Xian_jin_feng\论文\2.tif');
subplot(223)
imshow(glcm3)
imwrite(glcm3,'F:\Litchi\Indoor\Xian_jin_feng\论文\3.tif');
subplot(224)
imshow(glcm4)
imwrite(glcm4,'F:\Litchi\Indoor\Xian_jin_feng\论文\4.tif');

clear all;
clc
for ts = 1
    for pp = 1
        if ts == 1 && pp == 1
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230622\VNIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230622\VNIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai.xlsx');
            i1 = 1;
            i2 = 50;
            t1 = 1;
            t2 = 991;
            p1 = 1;
            p2 = 960;
            a123 = 991;
            b123 = 960;
            boduan = 176;
            ern = [2,7,10,11,12,13,14,15,16,17,19,21,22,23,24,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112];
            ttt = 49;
        end
        if ts == 1 && pp == 2
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230622\SWIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230622\SWIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header2.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai2.xlsx');
            i1 = 1;
            i2 = 50;
            t1 = 1;
            t2 = 333;
            p1 = 1;
            p2 = 320;
            a123 = 333;
            b123 = 320;
            boduan = 256;
            ern = [120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
            ttt = 16;
        end
        if ts == 2 && pp == 1
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230704\VNIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230704\VNIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai.xlsx');
            i1 = 1;
            i2 = 60;
            t1 = 1;
            t2 = 991;
            p1 = 1;
            p2 = 960;
            a123 = 991;
            b123 = 960;
            boduan = 176;
            ern = [2,7,10,11,12,13,14,15,16,17,19,21,22,23,24,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112];
            ttt = 49;
        end
        if ts == 2 && pp == 2
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230704\SWIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230704\SWIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header2.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai2.xlsx');
            i1 = 1;
            i2 = 60;
            t1 = 1;
            t2 = 333;
            p1 = 1;
            p2 = 320;
            a123 = 333;
            b123 = 320;
            boduan = 256;
            ern = [120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
            ttt = 16;
        end
        if ts == 3 && pp == 1
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230705\VNIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230705\VNIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai.xlsx');
            i1 = 61;
            i2 = 150;
            t1 = 1;
            t2 = 991;
            p1 = 1;
            p2 = 960;
            a123 = 991;
            b123 = 960;
            boduan = 176;
            ern = [2,7,10,11,12,13,14,15,16,17,19,21,22,23,24,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112];
            ttt = 49;
        end
        if ts == 3 && pp == 2
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230705\SWIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230705\SWIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header2.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai2.xlsx');
            i1 = 61;
            i2 = 144;
            t1 = 1;
            t2 = 333;
            p1 = 1;
            p2 = 320;
            a123 = 333;
            b123 = 320;
            boduan = 256;
            ern = [120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
            ttt = 16;
        end
        if ts == 4 && pp == 1
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230706\VNIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230706\VNIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai.xlsx');
            i1 = 151;
            i2 = 220;
            t1 = 1;
            t2 = 991;
            p1 = 1;
            p2 = 960;
            a123 = 991;
            b123 = 960;
            boduan = 176;
            ern = [2,7,10,11,12,13,14,15,16,17,19,21,22,23,24,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112];
            ttt = 49;
        end
        if ts == 4 && pp == 2
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230706\SWIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230706\SWIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header2.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai2.xlsx');
            i1 = 151;
            i2 = 220;
            t1 = 1;
            t2 = 333;
            p1 = 1;
            p2 = 320;
            a123 = 333;
            b123 = 320;
            boduan = 256;
            ern = [120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
            ttt = 16;
        end        
        if ts == 5 && pp == 1
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230707\VNIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230707\VNIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai.xlsx');
            i1 = 221;
            i2 = 270;
            t1 = 1;
            t2 = 991;
            p1 = 1;
            p2 = 960;
            a123 = 991;
            b123 = 960;
            boduan = 176;
            ern = [2,7,10,11,12,13,14,15,16,17,19,21,22,23,24,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112];
            ttt = 49;
        end
        if ts == 5 && pp == 2
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230707\SWIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230707\SWIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header2.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai2.xlsx');
            i1 = 221;
            i2 = 270;
            t1 = 1;
            t2 = 333;
            p1 = 1;
            p2 = 320;
            a123 = 333;
            b123 = 320;
            boduan = 256;
            ern = [120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
            ttt = 16;
        end
        if ts == 6 && pp == 1
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230710\VNIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230710\VNIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai.xlsx');
            i1 = 1;
            i2 = 50;
            t1 = 1;
            t2 = 991;
            p1 = 1;
            p2 = 960;
            a123 = 991;
            b123 = 960;
            boduan = 176;
            ern = [2,7,10,11,12,13,14,15,16,17,19,21,22,23,24,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112];
            ttt = 49;
        end
        if ts == 6 && pp == 2
            imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\20230710\SWIR\';
            imgDataPath2='F:\Litchi\Indoor\Xian_jin_feng\5_纹理特征\20230710\SWIR\';
            hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header2.hdr';
            heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai2.xlsx');
            i1 = 1;
            i2 = 50;
            t1 = 1;
            t2 = 333;
            p1 = 1;
            p2 = 320;
            a123 = 333;
            b123 = 320;
            boduan = 256;
            ern = [120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
            ttt = 16;
        end   


        imgDataDir  = dir([imgDataPath '*.raw']); 

        for tt = 1:((i2-i1+1)*2)
        
        mkdir([imgDataPath2,imgDataDir(tt).name]);
        newStr = strrep(imgDataDir(tt).name, '.raw', '');
        
        imagefile2=[imgDataPath newStr,'\4_lunkuo.jpg'];

        wert = imread(imagefile2);
        imagefile=imgDataDir(tt).name;
        savefold=[imgDataPath2 imgDataDir(tt).name,'\'];

        hdrfilename=hdrfile;
        imagefilename=[imgDataPath imagefile];
        savefolder=savefold;
        fid = fopen(hdrfilename,'r');
        info = fread(fid,'char=>char');
        info=info';%默认读入列向量，须要转置为行向量才适于显示
        fclose(fid);
        %查找列数
        a=strfind(info,'samples = ');
        b=length('samples = ');
        c=strfind(info,'lines');
        samples=[];
        for i=a+b:c-1
        samples=[samples,info(i)];
        end
        samples=str2num(samples);
        %查找行数
        a=strfind(info,'lines = ');
        b=length('lines = ');
        c=strfind(info,'bands');
        lines=[];
        for i=a+b:c-1
        lines=[lines,info(i)];
        end
        lines=str2num(lines);
        %查找波段数
        a=strfind(info,'bands = ');
        b=length('bands = ');
        c=strfind(info,'header offset');
        bands=[];
        for i=a+b:c-1
        bands=[bands,info(i)];
        end
        bands=str2num(bands);
        %查找波长数目
        a=strfind(info,'wavelength = {');
        b=length('wavelength = {');
        % c=strfind(info,' }');
        wavelength=[];
        for i=a+b:length(info)
            wavelength=[wavelength,info(i)];
        end
        wave=sscanf(wavelength,'%f,');
        %查找数据类型
        a=strfind(info,'data type = ');
        b=length('data type = ');
        c=strfind(info,'interleave');
        datatype=[];
        for i=a+b:c-1
        datatype=[datatype,info(i)];
        end
        datatype=str2num(datatype);
        precision=[];
        switch datatype
        case 1
        precision='uint8=>uint8';%头文件中datatype=1对应ENVI中数据类型为Byte，对应MATLAB中数据类型为uint8
        case 2
        precision='int16=>int16';%头文件中datatype=2对应ENVI中数据类型为Integer，对应MATLAB中数据类型为int16
        case 12
        precision='uint16=>uint16';%头文件中datatype=12对应ENVI中数据类型为Unsighed Int，对应MATLAB中数据类型为uint16
        case 3
        precision='int32=>int32';%头文件中datatype=3对应ENVI中数据类型为Long Integer，对应MATLAB中数据类型为int32
        case 13
        precision='uint32=>uint32';%头文件中datatype=13对应ENVI中数据类型为Unsighed Long，对应MATLAB中数据类型为uint32
        case 4
        precision='float32=>float32';%头文件中datatype=4对应ENVI中数据类型为Floating Point，对应MATLAB中数据类型为float32
        case 5
        precision='double=>double';%头文件中datatype=5对应ENVI中数据类型为Double Precision，对应MATLAB中数据类型为double
        otherwise
        error('invalid datatype');%除以上几种常见数据类型之外的数据类型视为无效的数据类型
        end
        %查找数据格式
        a=strfind(info,'interleave = ');
        b=length('interleave = ');
        c=strfind(info,'sensor type');
        interleave=[];
        for i=a+b:c-1
        interleave=[interleave,info(i)];
        end
        interleave=strtrim(interleave);%删除字符串中的空格
        %读取图像文件
        fid = fopen(hdrfilename, 'r');
        data = multibandread(imagefilename,[lines samples bands],precision,0,interleave,'ieee-le');
        data= double(data);


        for t = 1:a123
            for p = 1:b123
                if wert(t,p) >= 10
                    if t>t1
                        t1 = t;
                    end
                    if p>p1
                        p1 = p;
                    end
                end
            end
        end

        for t = a123:-1:1
            for p = b123:-1:1
                if wert(t,p) >= 10
                    if t<t2
                        t2 = t;
                    end
                    if p<p2
                        p2 = p;
                    end
                end
            end
        end     

        wert2 = [];
        for t6 = 1:a123
            for p6 = 1:b123
                if wert(t6,p6) >= 10
                    wert2(t6,p6) = 1;
                end
                if wert(t6,p6) < 10
                    wert2(t6,p6) = 0;
                end    
            end
        end

        heibai2 = [];
        heibai3 = [];
        wert4 = [];
        wert3 = wert2(t2:t1,p2:p1);

        for i = 1:boduan
            wert4(:,:,i) = wert3;
        end

        for t3 = 1:(t1-t2+1)
            for p3 = 1:(p1-p2+1)
                heibai2(t3,p3,:) = heibai(:,3);
                heibai3(t3,p3,:) = heibai(:,2)-heibai(:,3);
            end
        end

        ppt = [];
        er = [];
        er2 = [];

        ppt = data(t2:t1,p2:p1,:)-heibai2;
        er = ppt./heibai3.*wert4;
        save_path=strcat(savefolder,'1.mat');
        save_path2=strcat(savefolder,'1.bmp');
        save_path3=strcat(savefolder,'2.bmp');
        save_path4=strcat(savefolder,'3.bmp');
        save_path5=strcat(savefolder,'4.bmp');
        save_path6=strcat(savefolder,'5.bmp');
        save_path7=strcat(savefolder,'6.bmp');
        save_path8=strcat(savefolder,'7.bmp');
        
        if pp == 1
            ern2 = ern + 46 - 1;
        end
        if pp == 2
            ern2 = ern - 119 + 24;
        end
        
        er3 = er(:,:,ern2);
        max_yu = max(max(max(er3)));
        max_yu2 = max(max(er3(:,:,ttt)));
        er2 = er(:,:,ern2)/max_yu;
        
        save(save_path,'er2');
        imwrite(er3(:,:,ttt)/max_yu2,save_path2);
        imwrite(er3(:,:,ttt)/max_yu2*8,save_path3);

        wert5 = [];
        feature_after_PCA = [];
        RES = [];
        [m,n,p]=size(er2);%确定最终生成二维矩阵的大小
        t=m*n;%207400
        wert5=reshape(er2,t,p);
        [pc,score,latent,tsquare]=pca(wert5);%pc为主成分系数，score为主成分的结果，latent为方差
        feature_after_PCA=score(:,1:3);
        RES=reshape(feature_after_PCA,m,n,3);%取前三维，把矩阵还原为三维% imwrite(RES(..,1),'1.jpg);
        imwrite(RES,save_path4);
        imwrite(RES(:,:,1),save_path5);
        imwrite(RES(:,:,2),save_path6);
        imwrite(RES(:,:,3),save_path7);
        if pp ==1
            t1 = 1;
            t2 = 991;
            p1 = 1;
            p2 = 960;
        end
        if pp ==2
            t1 = 1;
            t2 = 333;
            p1 = 1;
            p2 = 320;
        end
% 保存图像
        end
    end
end

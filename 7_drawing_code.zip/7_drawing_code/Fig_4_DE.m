clear all;
clc


% 2、数据预览
b = xlsread("F:\Litchi\Indoor\Xian_jin_feng\新建 Microsoft Excel 工作表.xlsx");
% b2 = xlsread("F:\Litchi\Indoor\Xian_jin_feng\2.xlsx");
% b3 = [];
% 
% for i = 1:62
%     t = b(i,4);
%     b3(i) = b2(t,81);
% end
% b3 = b3';

% b2 = [];
% 
% for i = 1:62
%     for j = 1:307
%         a = roundn((b(i,2) - b(j,1)),-8);
%         if a == 0
%             b2(i) = j;
%         end
%     end
% end
% 
% b2 = b2';

b3 = [];

for i = 1:62
    if b(i,1)<20 || b(i,2)<17 || b(i,4)<0.1 
        b3(i) = 3;
    else
        if b(i,1)<23 || b(i,2)<18 || b(i,4)<0.1 
            b3(i) = 2;
        else
            if b(i,1)>=23 || b(i,2)>=18 || b(i,4)>=0.1 
                b3(i) = 1;
            end
        end
    end
end

b3 = b3';


b4 = [];

for i = 1:62
    if b(i,1)<20 || b(i,3)<17 || b(i,5)<0.1 
        b4(i) = 3;
    else
        if b(i,1)<23 || b(i,3)<18 || b(i,5)<0.1 
            b4(i) = 2;
        else
            if b(i,1)>=23 || b(i,3)>=18 || b(i,5)>=0.1 
                b4(i) = 1;
            end
        end
    end
end

b4 = b4';

h = figure;
set(h,'position',[300 300 800 300]);
% set(h,'position',[300 300 360 350]);
subplot(1,2,1)
xx = 0:80;
scatter(b(1,6),b(1,7),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
scatter(b(1,2),b(1,3),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
plot(xx,xx,'k--','LineWidth',1.5);hold on;
scatter(b(:,6),b(:,7),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
scatter(b(:,2),b(:,3),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
xlabel({'\fontname{Arial}Measured SSC (%)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Predicated SSC (%)'},'FontSize',12, 'FontWeight', 'bold');
% title({'\fontname{Times New Roman}Validation models'},'FontSize',12);
set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5, 'FontWeight', 'bold');
box on;
set(gca,'TickDir','in')
set(gca,'xlim',[15 21]);
set(gca,'ylim',[15 21]);
set(gca,'XTick',15:2:21);
set(gca,'YTick',15:2:21);
str21 = {'\fontname{Arial}Rc^{\fontsize{6}2}=0.9213'};
str22 = {'\fontname{Arial}RMSEC=0.2691'};
str23 = {'\fontname{Arial}Rp^{\fontsize{6}2}=0.9148'};
str24 = {'\fontname{Arial}RMSEP=0.3042'};
% str25 = {'\fontname{Arial}RPD=2.7599'};
str1 = [str21 str22 str23 str24];
text(15.3,20,str1,'FontSize',12, 'FontWeight', 'bold')
legend("Cal.","Pre.","location","southeast",'FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold')

subplot(1,2,2)
xx = -10:80;
scatter(b(1,8),b(1,9),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
scatter(b(1,4),b(1,5),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
plot(xx,xx,'k--','LineWidth',1.5);hold on;
scatter(b(:,8),b(:,9),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
scatter(b(:,4),b(:,5),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
xlabel({'\fontname{Arial}Measured AC (mg·g^{\fontsize{6}-1}·FW)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Predicated AC','(mg·g^{\fontsize{6}-1}·FW)'},'FontSize',12, 'FontWeight', 'bold');
% title({'\fontname{Times New Roman}Validation models'},'FontSize',12);
set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5, 'FontWeight', 'bold');
box on;
set(gca,'TickDir','in')
set(gca,'xlim',[-0.1 0.8]);
set(gca,'ylim',[-0.1 0.8]);
set(gca,'XTick',-0.1:0.3:0.8);
set(gca,'YTick',-0.1:0.3:0.8);
str21 = {'\fontname{Arial}Rc^{\fontsize{6}2}=0.8475'};
str22 = {'\fontname{Arial}RMSEC=0.0556'};
str23 = {'\fontname{Arial}Rp^{\fontsize{6}2}=0.8455'};
str24 = {'\fontname{Arial}RMSEP=0.0653'};
% str25 = {'\fontname{Arial}RPD=2.1406'};
str1 = [str21 str22 str23 str24];
legend("Cal.","Pre.","location","southeast",'FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold')
text(-0.05,0.65,str1,'FontSize',12, 'FontWeight', 'bold')

% % 
% subplot(122)
% [mat,order] = confusionmat(b4, b3);
%  % 使用 flipud 函数上下翻转矩阵
% mat = flipud(mat);
%  %mat = rand(10);           %# A 5-by-5 matrix of random values from 0 to 1
% % mat(3,3) = 0;            %# To illustrate
% % mat(5,2) = 0;            %# To illustrate
% imagesc(mat);            %# Create a colored plot of the matrix values
% colormap(flipud(gray));  %# Change the colormap to gray (so higher values are
%                          %#   black and lower values are white)
%  
% textStrings = num2str(mat(:));  %# Create strings from the matrix values
% textStrings = strtrim(cellstr(textStrings));  %# Remove any space padding
%  
% [x,y] = meshgrid(1:3);   %# Create x and y coordinates for the strings
% hStrings = text(x(:),y(:),textStrings(:),...      %# Plot the strings
%                 'HorizontalAlignment','center', 'FontWeight', 'bold');
% midValue = mean(get(gca,'CLim'));  %# Get the middle value of the color range
% textColors = repmat(mat(:) > midValue,1,3);  %# Choose white or black for the
%                                              %#   text color of the strings so
%                                              %#   they can be easily seen over
%                                              %#   the background color
% set(hStrings,{'Color'},num2cell(textColors,2),'FontSize',12,'Fontname', 'Arial');  %# Change the text colors
%  
% set(gca,'XTick',1:3,...                         %# Change the axes tick marks
%         'XTickLabel',{'Grade 1','Grade 2','Grade 3'},...  %#   and tick labels
%         'YTick',1:3,...
%         'YTickLabel',{'Grade 3','Grade 2','Grade 1'},...
%         'TickLength',[0 0],'FontSize',12,'Fontname', 'Arial', 'LineWidth',1.5, 'FontWeight', 'bold');
% ytickangle(90);
% xlabel('Actual Grade','FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold');
% ylabel('Predicted Grade','FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold');
% 
% 





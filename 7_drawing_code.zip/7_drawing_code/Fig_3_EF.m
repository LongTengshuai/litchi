clear all;
clc
fanshe = xlsread('F:\Litchi\Indoor\Xian_jin_feng\6_otherscode\fanshe2.xlsx');
toushe = xlsread('F:\Litchi\Indoor\Xian_jin_feng\6_otherscode\toushe.xlsx');


h = figure;
set(h,'position',[100 100 800 600]);
subplot(321)
ert = fanshe(:,[10,13,14,15])/10;
plot(fanshe(:,1),ert,'LineWidth',1.5);hold on;
xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Reflection'},'FontSize',12, 'FontWeight', 'bold');
xticks(900:200:1700);
yticks(0:0.2:0.8);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on'); 
axis([900 1700 -0.005 0.8]);
leg = legend('\fontname{Arial}90°','\fontname{Arial}180°','\fontname{Arial}270°','\fontname{Arial}360°', 'FontWeight', 'bold');
leg.ItemTokenSize = [15,20];



toushe(:,15) = toushe(:,15)*0.96;
subplot(323)
ert2 = toushe(:,[10,11,12,15])*1.5/10;
plot(toushe(:,1),ert2,'LineWidth',1.5);hold on;
xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Ts'},'FontSize',12, 'FontWeight', 'bold');
xticks(500:200:1300);
yticks(0:0.2:0.8);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on'); 
axis([500 1300 -0.005 0.8]);
leg = legend('\fontname{Arial}0°','\fontname{Arial}90°','\fontname{Arial}180°','\fontname{Arial}270°', 'FontWeight', 'bold');leg.ItemTokenSize = [15,20];
leg.ItemTokenSize = [15,20];


subplot(322)
ert = fanshe(:,[10,13,14,15])/10;
werq4 = (ert(:,3)-ert(:,2))./(ert(:,3)+ert(:,2));werq1_1 = mean(abs(werq4(71:305)));
werq5 = (ert(:,4)-ert(:,2))./(ert(:,4)+ert(:,2));werq2_1 = mean(abs(werq5(71:305)));
werq6 = (ert(:,1)-ert(:,2))./(ert(:,1)+ert(:,2));werq3_1 = mean(abs(werq6(71:305)));

ert3=mapminmax(ert',0,1);
werr = ert3';
werq1 = (werr(:,3)-werr(:,2))./(werr(:,3)+werr(:,2));werq1_2 = mean(abs(werq1(71:305)));
werq2 = (werr(:,4)-werr(:,2))./(werr(:,4)+werr(:,2));werq2_2 = mean(abs(werq2(71:305)));
werq3 = (werr(:,1)-werr(:,2))./(werr(:,1)+werr(:,2));werq3_2 = mean(abs(werq3(71:305)));

plot(fanshe(:,1),werr(:,2),'LineWidth',1.5);hold on;
plot(fanshe(:,1),werr(:,3),'LineWidth',1.5);hold on;
plot(fanshe(:,1),werr(:,4),'LineWidth',1.5);hold on;
plot(fanshe(:,1),werr(:,1),'LineWidth',1.5);hold on;

xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Reflection-Norm'},'FontSize',12, 'FontWeight', 'bold');
xticks(500:300:1700);
yticks(0:0.2:1);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on'); 
axis([500 1700 -0.005 1]);
leg = legend('\fontname{Arial}0°','\fontname{Arial}90°','\fontname{Arial}180°','\fontname{Arial}270°', 'FontWeight', 'bold');leg.ItemTokenSize = [15,20];


subplot(324)
werq7 = (ert2(:,3)-ert2(:,2))./(ert2(:,3)+ert2(:,2));werq1_3 = mean(abs(werq7(70:222)));
werq8 = (ert2(:,4)-ert2(:,2))./(ert2(:,4)+ert2(:,2));werq2_3 = mean(abs(werq8(70:222)));
werq9 = (ert2(:,1)-ert2(:,2))./(ert2(:,1)+ert2(:,2));werq3_3 = mean(abs(werq9(70:222)));
ert4=mapminmax(ert2',0,1);
ert4 = ert4';
werq10 = (ert4(:,3)-ert4(:,2))./(ert4(:,3)+ert4(:,2));werq1_4 = mean(abs(werq10(70:222)));
werq11 = (ert4(:,4)-ert4(:,2))./(ert4(:,4)+ert4(:,2));werq2_4 = mean(abs(werq11(70:222)));
werq12 = (ert4(:,1)-ert4(:,2))./(ert4(:,1)+ert4(:,2));werq3_4 = mean(abs(werq12(70:222)));
ert4 = ert4';
plot(toushe(:,1),ert4'-0.005,'LineWidth',1.5);hold on;
xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Tnorm'},'FontSize',12, 'FontWeight', 'bold');
xticks(500:200:1300);
yticks(0:0.2:1);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on'); 
axis([500 1300 0 1]);
leg = legend('\fontname{Arial}0°','\fontname{Arial}90°','\fontname{Arial}180°','\fontname{Arial}270°', 'FontWeight', 'bold');
leg.ItemTokenSize = [15,20];



% 
% subplot(325)
% % CC = xlsread('G:\新建 Microsoft Excel 工作表 (2).xlsx');
% CC = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\VNIR.xlsx');
% heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\heibai.xlsx');
% x = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\x.xlsx');
% xx=ones(176,1);
% 
% wer1 = heibai(:,2)';
% wer2 = heibai(:,3)';
% 
% for i =3:377
%     wer(i-2,:) = (CC(i,2:177) - wer2)./(wer1 - wer2);
% end
% 
% plot(x,wer/10,'LineWidth',1.5);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}VNIR'},'FontSize',12, 'FontWeight', 'bold');
% yticks(0:0.2:0.8);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% axis([400 1000 -0.001 0.8]);
% 
% 
% subplot(326)
% CC2 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\SWIR.xlsx');
% heibai2 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\heibai2.xlsx');
% x2 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\x2.xlsx');
% xx2=ones(256,1);
% 
% wer3 = heibai2(:,2)';
% wer4 = heibai2(:,3)';
% 
% for i =3:377
%     wer5(i-2,:) = 0.54*(CC2(i,2:257) - wer4)./(wer3 - wer4);
% end
% 
% plot(x2,wer5/10,'LineWidth',1.5);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}SWIR'},'FontSize',12, 'FontWeight', 'bold');
% xticks(900:200:1700);
% yticks(0:0.2:0.8);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% axis([900 1700 -0.001 0.8]);




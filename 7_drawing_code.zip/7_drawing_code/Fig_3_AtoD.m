clear all;
clc


h = figure;
set(h,'position',[100 100 800 600]);
% subplot(321)
sd = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_original_spectra_and_spectral_extraction\3_Origin_trans_spectra\VNIR_SWIR_R.xlsx');
A2 = sd(3:377,182);
A2([43,51,112,203,274,325]) = [];
A_no_nan_cols_map = mapminmax(A2',0.005,1);
A_no_nan_cols_map = A_no_nan_cols_map';

wer12 = sd(3:377,2:181);
x3 = sd(1,2:181);
sd2(:,119:180) = 0.54*sd(:,120:181);
sd2(:,1:118) = sd(:,2:119);
sd2([1,2,45,53,114,205,276,327],:) = [];
% 
% dq=jet(369); 
% for i = 1:369
%     QWER = sd2(i,:)/10;
%     plot(x3,QWER','color',dq(round(369*A_no_nan_cols_map(i)),:),'LineWidth',1.5);hold on;
% end
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}Ts'},'FontSize',12, 'FontWeight', 'bold');
% xticks(500:200:1300);
% yticks(0:0.2:0.8);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% axis([500 1300 -0.005 0.8]);

% subplot(322)
% sd232=mapminmax(sd2,0.005,1);
% 
% dq=jet(369); 
% for i = 1:369
%     QWER = sd232(i,:);
%     plot(x3,QWER','color',dq(round(369*A_no_nan_cols_map(i)),:),'LineWidth',1.5);hold on;
% end
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}Tnorm'},'FontSize',12, 'FontWeight', 'bold');
% xticks(500:200:1300);
% yticks(0:0.2:1);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% axis([500 1300 -0.005 1]);



subplot(323)
A3 = sd(3:377,183);
A3([43,51,112,134,203,274,325]) = [];
A_no_nan_cols_map2 = mapminmax(A3',0.005,1);
A_no_nan_cols_map2 = A_no_nan_cols_map2';

sd2(131,:) = [];

A3([213,239,240,268],:) = [];
A3([70,74,79,149,152,206,217,264,290,329,332,333,357],:) = [];
A_no_nan_cols_map3 = mapminmax(A3',0.005,1);
A_no_nan_cols_map3 = A_no_nan_cols_map3';

sd2([213,239,240,268],:) = [];
sd2([70,74,79,149,152,206,217,264,290,329,332,333,357],:) = [];

sd2(149:154,:) = [];
A_no_nan_cols_map3(149:154,:) = [];
correlations1 = corr(sd2, A_no_nan_cols_map3);

dq=jet(345); 
for i = 1:345
    QWER2 = sd2(i,:)/10;
    plot(x3,QWER2','color',dq(round(345*A_no_nan_cols_map2(i)),:),'LineWidth',1.5);hold on;
end

xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Ts'},'FontSize',12, 'FontWeight', 'bold');
xticks(500:200:1300);
yticks(0:0.2:0.8);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on');
axis([500 1300 -0.005 0.8]);



subplot(324)
A12 = mapminmax(sd2/10,0.005,1);
correlations2 = corr(A12, A_no_nan_cols_map3);
dq=jet(345); 
for i = 345:-1:1
    QWER2 = A12(i,:);
    plot(x3,QWER2,'color',dq(round(345*A_no_nan_cols_map2(i)),:),'LineWidth',1.5);hold on;
end

xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel({'\fontname{Arial}Tnorm'},'FontSize',12, 'FontWeight', 'bold');
xticks(500:200:1300);
yticks(0:0.2:1);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on');
axis([500 1300 -0.005 1]);



b = xlsread("F:\Litchi\Indoor\Xian_jin_feng\5_texture_features\VNIR_SWIR_R_G_ALL.xlsx");
x = b(1,2:181);
b1_1 = b(3:106,2:181);
b1_2 = b(108:210,2:181);
b1_3 = b(212:315,2:181);
b1 = [b1_1; b1_2;b1_3];
b1(42,:)=[];
b1([140,141,148,222,231,269,274,275,282],:)=[];
b1(138,:)=[];

b2 = b(:,249);
b2([1,2,107,211])=[];
% b2([42,140,141,148,222,231,269,274,275,282])=[];
b2(42)=[];
b2([140,141,148,222,231,269,274,275,282])=[];
b2(138)=[];
b3 = mapminmax(b2',0.005,1);
newColorList=[244,111,68;127,203,164;75,101,175]./255;
subplot(325)
dq=jet(300); 

correlations3 = corr(b1, b3');

for i = 1:300
    QWER2 = b1(i,:)/10;
    plot(x,QWER2,'color',dq(round(300*b3(i)),:),'LineWidth',1.5);hold on;
end

xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
xticks(500:200:1300);
ylabel({'\fontname{Arial}Ts'},'FontSize',12);
yticks(0:0.2:0.8);
set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
set(gca,'TickDir','in')
set(gca, 'FontWeight', 'bold');
axis([500 1300 0 0.8]);



subplot(326)
dq=jet(300); 
A13 = mapminmax(b1/10,0.005,1);
correlations4 = corr(A13, b3');
for i = 300:-1:1
    QWER3 = A13(i,:);
    plot(x,QWER3,'color',dq(round(300*b3(i)),:),'LineWidth',1.5);hold on;
end

xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
xticks(500:200:1300);
ylabel({'\fontname{Arial}Tnorm'},'FontSize',12);
yticks(0:0.2:1);
set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
set(gca,'TickDir','in')
set(gca, 'FontWeight', 'bold');
axis([500 1300 0 1]);

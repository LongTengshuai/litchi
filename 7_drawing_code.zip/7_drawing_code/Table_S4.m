clear all;
clc

y_true = [0.282	0.174	0.584	0.182	0.434	0.215	0.292	0.575	0.257];  % 用你的真实数据代替
y_pred = [0.268	0.135	0.653	0.158	0.452	0.196	0.342	0.526	0.290];  % 用你的预测数据代替

% 计算 R²
SS_res = sum((y_true - y_pred).^2);  % 误差平方和
SS_tot = sum((y_true - mean(y_true)).^2);  % 总平方和
R2 = 1 - (SS_res / SS_tot);

% 计算 RMSE
RMSE = sqrt(mean((y_true - y_pred).^2));


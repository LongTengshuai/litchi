clear all;
clc

newColorList=[244,111,68;127,203,164;75,101,175]./255;
% 2、数据预览
b = xlsread("F:\Litchi\Indoor\Xian_jin_feng\5_texture_features\VNIR_SWIR_R_G_ALL.xlsx");
x = b(1,2:181);
b1_1 = b(3:106,2:181);
b1_2 = b(108:210,2:181);
b1_3 = b(212:315,2:181);
b1 = [b1_1; b1_2;b1_3];
% b1 = b(:,1:180);
% 归一化
A1=mapminmax(b1(:,1:180),0.005,1);

% % 一阶导
A3=diff(b1');A3=A3';

% MSC
bb=mean(b1);
A6=msc(b1,bb);

% % 一阶导
A7=diff(A1');A7=A7';

% MSC
bb2=mean(A1);
A8=msc(A1,bb2);



h = figure;
set(h,'position',[100 50 800 250]);
% subplot(321)
sd = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_original_spectra_and_spectral_extraction\3_Origin_trans_spectra\VNIR_SWIR_R.xlsx');
A2 = sd(3:377,182);
A2([43,51,112,203,274,325]) = [];
A_no_nan_cols_map = mapminmax(A2',0.005,1);
A_no_nan_cols_map = A_no_nan_cols_map';

wer12 = sd(3:377,2:181);
x3 = sd(1,2:181);
sd2(:,119:180) = 0.54*sd(:,120:181);
sd2(:,1:118) = sd(:,2:119);
% sd3 = sd2(~any(isnan(sd2), 2), :);
sd2([1,2,45,53,114,205,276,327],:) = [];

% dq=jet(369); 
% for i = 1:369
%     QWER = sd2(i,:)/10;
%     plot(x3,QWER','LineWidth',1.5);hold on;
% end
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}VNIR-SWIR'},'FontSize',12, 'FontWeight', 'bold');
% xticks(500:200:1300);
% yticks(0:0.2:0.8);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% axis([500 1300 -0.005 0.8]);

ern = [2,7,10,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112,120,121,122,126,128,133,137,138,139,140,141,147,149,150,151,152,153,159,161,162,165,169,170,172,173,178];
wert = mean(A8(1:104,:));
x = b(1,2:181);
% subplot(323)
% plot(x,wert,'k','LineWidth',1.5);hold on;
% scatter(x(ern),wert(ern),9,'r','filled');hold on;
% scatter(0,1,9,'k','filled');hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% xticks(500:200:1300);
% ylabel({'\fontname{Arial}Norm-MSC'},'FontSize',12);
% yticks(0:0.2:1);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
% set(gca,'TickDir','in')
% set(gca, 'FontWeight', 'bold');
% axis([500 1300 0 1]);
% leg = legend({'Spectrum','SPF for SSC'},'FontSize',10,'fontname','Arial','Location','northeast','LineWidth',1.5);
% leg.ItemTokenSize = [10,20];


ern2 = [7,11,12,13,16,17,18,19,25,26,27,30,37,45,47,48,49,52,69,71,83,86,89,95,96,98,100,105,106,107,108,118,119,120,122,127,130,132,134,149,157,165,181]-1;
wert = mean(A8(1:104,:));

% subplot(324)
% plot(x,wert,'k','LineWidth',1.5);hold on;
% scatter(x(ern2),wert(ern2),9,'r','filled');hold on;
% scatter(0,1,9,'k','filled');hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12);
% xticks(500:200:1300);
% ylabel({'\fontname{Arial}Norm-MSC'},'FontSize',12);
% yticks(0:0.2:1);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
% set(gca,'TickDir','in')
% set(gca, 'FontWeight', 'bold');
% axis([500 1300 0 1]);
% leg = legend({'Spectrum','SPF for AC'},'FontSize',10,'fontname','Arial','Location','northeast','LineWidth',1.5);
% leg.ItemTokenSize = [10,20];


plot(1:3,b(3,199:201)/100,'k-','LineWidth',1.5);hold on;
plot(4:6,b(3,202:204)/100,'k-','LineWidth',1.5);hold on;
plot(7:9,b(3,205:207)/100,'k-','LineWidth',1.5);hold on;
scatter(1:3,b(3,199:201)/100,25,'k','filled');hold on;
scatter(4:6,b(3,202:204)/100,25,'k','filled');hold on;
scatter(7:9,b(3,205:207)/100,25,'k','filled');hold on;
xlabel({'\fontname{Arial}Spectral parameter'},'FontSize',12);
xticks(0:2:10);
ylabel({'\fontname{Arial}Value'},'FontSize',12);
set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
set(gca,'TickDir','in')
set(gca, 'FontWeight', 'bold');

% legend1 = legend({'PC1','PC2','PC3','SSD','Mean','Variance','Skewness',''},...
%     'FontSize',10,'fontname','Arial','Location','northeast',...
%     'LineWidth',1.5,'NumColumns', 2);
% legend1.ItemTokenSize = [10,20];


GLCM = b(3:315,182:189);
SF = b(3:315,208:218);
all = [GLCM,SF];
all([105,209],:)=[];
a1=mapminmax(all',0.005,1);
a1 = a1';
w1 = [24.42 4.94 2.9];
w2 = [24424.5 1156.3 28.7];

w3 = [a1(1,[9:13,15:19]) w1/30];


plot(10:7+10,a1(1,1:8),'k-','LineWidth',1.5);hold on;
plot(8+10:17+10,w3(1:10),'k-','LineWidth',1.5);hold on;
scatter(10:7+10,a1(1,1:8),25,'k','filled');hold on;
scatter(8+10:17+10,w3(1:10),25,'k','filled');hold on;


% xlabel({'\fontname{Arial}Structure parameter'},'FontSize',12);
% xticks(0:4:20);
% ylabel({'\fontname{Arial}Value'},'FontSize',12);
% yticks(0:0.2:1);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
% set(gca,'TickDir','in')
% set(gca, 'FontWeight', 'bold');
% axis([0 20 0 1]);
% legend1 = legend({'TF','MF','STF for SSC'},...
%     'FontSize',10,'fontname','Arial','Location','southeast',...
%     'LineWidth',1.5);
% legend1.ItemTokenSize = [10,20];

w2 = [24424.5 1156.3 28.7 10.8];

A = b(3,199:207)/100;
A1 = A.^(1/2);
plot(28:30,A1(1:3),'k-','LineWidth',1.5);hold on;
plot(31:33,A1(4:6),'k-','LineWidth',1.5);hold on;
plot(34:36,A1(7:9),'k-','LineWidth',1.5);hold on;
scatter(28:30,A1(1:3),25,'k','filled');hold on;
scatter(31:33,A1(4:6),25,'k','filled');hold on;
scatter(34:36,A1(7:9),25,'k','filled');hold on;

plot(37:40,w2(1:4)/30000,'k-','LineWidth',1.5);hold on;
scatter(37:40,w2(1:4)/30000,25,'k','filled');hold on;

A3 = w3.^(1/2);
A4=mapminmax(A3,0.005,1);
plot(41:50,A4(1:10),'k-','LineWidth',1.5);hold on;
scatter(41:50,A4(1:10),25,'k','filled');hold on;

xlabel('');
xticks(0:8:56);
ylabel({'\fontname{Arial}Value'},'FontSize',12);
yticks(-0.5:0.3:1.3);

set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5);
set(gca,'TickDir','in')
set(gca, 'FontWeight', 'bold');
axis([0 56 -0.5 1.3]);
% legend1 = legend({'TF','MF','STF for AC'},...
%     'FontSize',10,'fontname','Arial','Location','southeast',...
%     'LineWidth',1.5);
% legend1.ItemTokenSize = [10,20];

% 
% b = xlsread("F:\Litchi\Indoor\Xian_jin_feng\新建 Microsoft Excel 工作表.xlsx");
% h = figure;
% set(h,'position',[100 100 800 300]);
% subplot(121)
% xx = 0:80;
% scatter(b(1,6),b(1,7),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
% scatter(b(1,2),b(1,3),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
% plot(xx,xx,'k--','LineWidth',1.5);hold on;
% scatter(b(:,6),b(:,7),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
% scatter(b(:,2),b(:,3),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
% xlabel({'\fontname{Arial}Measured SSC (%)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}Predicated SSC (%)'},'FontSize',12, 'FontWeight', 'bold');
% % title({'\fontname{Times New Roman}Validation models'},'FontSize',12);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5, 'FontWeight', 'bold');
% box on;
% set(gca,'TickDir','in')
% set(gca,'xlim',[15 21]);
% set(gca,'ylim',[15 21]);
% set(gca,'XTick',15:2:21);
% set(gca,'YTick',15:2:21);
% str21 = {'\fontname{Arial}Rc^{\fontsize{6}2}=0.9065'};
% str22 = {'\fontname{Arial}RMSEC=0.2917'};
% str23 = {'\fontname{Arial}Rp^{\fontsize{6}2}=0.9129'};
% str24 = {'\fontname{Arial}RMSEP=0.3075'};
% % str25 = {'\fontname{Arial}RPD=2.7341'};
% str1 = [str21 str22 str23 str24];
% text(15.3,19.9,str1,'FontSize',12, 'FontWeight', 'bold')
% legend("Cal.","Pre.","location","southeast",'FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold')
% 
% subplot(122)
% xx = -10:80;
% scatter(b(1,8),b(1,9),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
% scatter(b(1,4),b(1,5),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
% plot(xx,xx,'k--','LineWidth',1.5);hold on;
% scatter(b(:,8),b(:,9),'MarkerEdgeColor','k', 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.2);hold on;
% scatter(b(:,4),b(:,5),'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'LineWidth',1.2);hold on;
% xlabel({'\fontname{Arial}Measured AC (mg·g^{\fontsize{6}-1}·FW)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}Predicated AC (mg·g^{\fontsize{6}-1}·FW)'},'FontSize',12, 'FontWeight', 'bold');
% % title({'\fontname{Times New Roman}Validation models'},'FontSize',12);
% set(gca,'FontSize',12,'Fontname', 'Arial','LineWidth',1.5, 'FontWeight', 'bold');
% box on;
% set(gca,'TickDir','in')
% set(gca,'xlim',[-0.1 0.8]);
% set(gca,'ylim',[-0.1 0.8]);
% set(gca,'XTick',-0.1:0.3:0.8);
% set(gca,'YTick',-0.1:0.3:0.8);
% str21 = {'\fontname{Arial}Rc^{\fontsize{6}2}=0.8411'};
% str22 = {'\fontname{Arial}RMSEC=0.0575'};
% str23 = {'\fontname{Arial}Rp^{\fontsize{6}2}=0.8493'};
% str24 = {'\fontname{Arial}RMSEP=0.0643'};
% % str25 = {'\fontname{Arial}RPD=2.0512'};
% str1 = [str21 str22 str23 str24];
% legend("Cal.","Pre.","location","southeast",'FontSize',12,'Fontname', 'Arial', 'FontWeight', 'bold')
% text(-0.05,0.640,str1,'FontSize',12, 'FontWeight', 'bold')
% 

clear all;
clc

a1 = load('E:\Hyperspectral_recovery\data\XJF\mat文件\20230711\52-1.raw\52-1.raw.mat');
a2 = imread('E:\Hyperspectral_recovery\data\XJF\mat文件\20230711\52-1.raw\52-1.raw_2.bmp');

a1_1 = a1.yi2(:,:,142);

t1 = min(min(a1_1));

t1_2 = max(max(a1_1));

K1=medfilt2(a1_1);


% for i= 1:200
%     for j =1:200
%         if K12(i,j) == 0
%             K12(i,j) = K12(i,j)-0.55;
%         end
%     end
% end

a = 0;b = 40;
h = figure;
set(h,'position',[50 50 1100 400]);
subplot(1,2,1)
imagesc(K1);caxis([-1 6]);axis off;hold on;
% subplot(1,2,2)
% imagesc(K2);caxis([a b+0.35]);axis off;hold on;

colormap(jet);


clear all;
clc

bb = xlsread('C:\Users\longteng\Desktop\tu\else\新建 Microsoft Excel 工作表 (3).xlsx');
bb1 = bb(:,16);
bb2 = bb(:,17);

imgDataPath='F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\1_原始光谱数据\';
imgDataPath2='C:\Users\longteng\Desktop\tu\else2\';
hdrfile='F:\Litchi\Indoor\Xian_jin_feng\2_ROI区域选取\matlab_code\header.hdr';
heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\heibai.xlsx');

t1 = 1;
t2 = 991;
p1 = 1;
p2 = 960;
a123 = 991;
b123 = 960;
boduan = 176;
ttt = 49;

ert = [];
ert2 = [];

for bbb = 1:62
    imgDataname  = [imgDataPath '20230' num2str(bb1(bbb)) '\VNIR\' num2str(bb2(bbb)) '-1.raw']; 
    imagefile2=[imgDataPath '20230' num2str(bb1(bbb)) '\VNIR\' num2str(bb2(bbb)) '-1\4_lunkuo.jpg'];

    wert = imread(imagefile2);
    savefold = imgDataPath2;
    
    hdrfilename = hdrfile;
    imagefilename = imgDataname;
    savefolder=savefold;
    fid = fopen(hdrfilename,'r');
    info = fread(fid,'char=>char');
    info=info';%默认读入列向量，须要转置为行向量才适于显示
    fclose(fid);
    %查找列数
    a=strfind(info,'samples = ');
    b=length('samples = ');
    c=strfind(info,'lines');
    samples=[];
    for i=a+b:c-1
    samples=[samples,info(i)];
    end
    samples=str2num(samples);
    %查找行数
    a=strfind(info,'lines = ');
    b=length('lines = ');
    c=strfind(info,'bands');
    lines=[];
    for i=a+b:c-1
    lines=[lines,info(i)];
    end
    lines=str2num(lines);
    %查找波段数
    a=strfind(info,'bands = ');
    b=length('bands = ');
    c=strfind(info,'header offset');
    bands=[];
    for i=a+b:c-1
    bands=[bands,info(i)];
    end
    bands=str2num(bands);
    %查找波长数目
    a=strfind(info,'wavelength = {');
    b=length('wavelength = {');
    % c=strfind(info,' }');
    wavelength=[];
    for i=a+b:length(info)
        wavelength=[wavelength,info(i)];
    end
    wave=sscanf(wavelength,'%f,');
    %查找数据类型
    a=strfind(info,'data type = ');
    b=length('data type = ');
    c=strfind(info,'interleave');
    datatype=[];
    for i=a+b:c-1
    datatype=[datatype,info(i)];
    end
    datatype=str2num(datatype);
    precision=[];
    switch datatype
    case 1
    precision='uint8=>uint8';%头文件中datatype=1对应ENVI中数据类型为Byte，对应MATLAB中数据类型为uint8
    case 2
    precision='int16=>int16';%头文件中datatype=2对应ENVI中数据类型为Integer，对应MATLAB中数据类型为int16
    case 12
    precision='uint16=>uint16';%头文件中datatype=12对应ENVI中数据类型为Unsighed Int，对应MATLAB中数据类型为uint16
    case 3
    precision='int32=>int32';%头文件中datatype=3对应ENVI中数据类型为Long Integer，对应MATLAB中数据类型为int32
    case 13
    precision='uint32=>uint32';%头文件中datatype=13对应ENVI中数据类型为Unsighed Long，对应MATLAB中数据类型为uint32
    case 4
    precision='float32=>float32';%头文件中datatype=4对应ENVI中数据类型为Floating Point，对应MATLAB中数据类型为float32
    case 5
    precision='double=>double';%头文件中datatype=5对应ENVI中数据类型为Double Precision，对应MATLAB中数据类型为double
    otherwise
    error('invalid datatype');%除以上几种常见数据类型之外的数据类型视为无效的数据类型
    end
    %查找数据格式
    a=strfind(info,'interleave = ');
    b=length('interleave = ');
    c=strfind(info,'sensor type');
    interleave=[];
    for i=a+b:c-1
    interleave=[interleave,info(i)];
    end
    interleave=strtrim(interleave);%删除字符串中的空格
    %读取图像文件
    fid = fopen(hdrfilename, 'r');
    data = multibandread(imagefilename,[lines samples bands],precision,0,interleave,'ieee-le');
    data= double(data);
    
    
    for t = 1:a123
        for p = 1:b123
            if wert(t,p) >= 10
                if t>t1
                    t1 = t;
                end
                if p>p1
                    p1 = p;
                end
            end
        end
    end
    
    for t = a123:-1:1
        for p = b123:-1:1
            if wert(t,p) >= 10
                if t<t2
                    t2 = t;
                end
                if p<p2
                    p2 = p;
                end
            end
        end
    end     
    
    wert2 = [];
    for t6 = 1:a123
        for p6 = 1:b123
            if wert(t6,p6) >= 10
                wert2(t6,p6) = 1;
            end
            if wert(t6,p6) < 10
                wert2(t6,p6) = 0;
            end    
        end
    end
    
    heibai2 = [];
    heibai3 = [];
    wert4 = [];
    wert3 = wert2(t2:t1,p2:p1);
    
    for i = 1:boduan
        wert4(:,:,i) = wert3;
    end
    
    for t3 = 1:(t1-t2+1)
        for p3 = 1:(p1-p2+1)
            heibai2(t3,p3,:) = heibai(:,3);
            heibai3(t3,p3,:) = heibai(:,2)-heibai(:,3);
        end
    end
    
    ppt = [];
    er = [];
    er2 = [];
    
    ppt = data(t2:t1,p2:p1,:)-heibai2;
    er = ppt./heibai3.*wert4;
    save_path=strcat(savefolder,num2str(bbb),'.mat');
    
%     ern = [2,7,10,11,12,13,14,15,16,17,19,21,22,23,24,25,28,30,33,35,36,37,38,39,40,42,46,47,51,55,56,57,60,61,62,63,65,67,71,73,78,81,83,87,92,94,95,98,101,103,111,112];
    ern = [3,8,10,11,12,16,17,18,21,24,26,27,31,37,38,39,44,46,47,49,52,71,89,96,98,100,105,107];
    
    ern2 = ern - 1;
    aa1 = size(er,1);aa2 = size(er,2);
    
    er3 = er(:,:,47:164);
    
    cc = reshape(er3,[aa1*aa2,164-47+1]);
    A1 = mapminmax(cc,0,1);
    A2 = reshape(A1,[aa1,aa2,164-47+1]);
    A3 = A2(:,:,ern2);
    
    aa3 = floor(aa1/3);
    aa4 = floor(aa2/3);
    
    A5 = [];
    
    for i = 1:aa3
        for j = 1:aa4
            aa5 = (1+3*(i-1));
            aa6 = (1+3*(j-1));
            for q = 1:28
                A5(i,j,q) = mean(A3(aa5:(aa5+2),aa6:(aa6+2),q),'all');
            end
        end
    end
    ert(bbb) = aa3;
    ert2(bbb) = aa4;
    A6 = reshape(A5,[aa3*aa4,28]);
%     save(save_path,'A6');

end





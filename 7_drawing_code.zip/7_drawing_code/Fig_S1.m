clear all;
clc
fanshe = xlsread('F:\Litchi\Indoor\Xian_jin_feng\新建文件夹\fanshe2.xlsx');
toushe = xlsread('F:\Litchi\Indoor\Xian_jin_feng\新建文件夹\toushe.xlsx');


h = figure;
set(h,'position',[100 100 800 300]);
% subplot(223)
% ert = fanshe(:,[10,13,14,15])/10;
% % plot(fanshe(:,1),ert(:,2),'LineWidth',1.5);hold on;
% plot(fanshe(:,1),ert(:,3)-ert(:,2),'LineWidth',1.5);hold on;
% plot(fanshe(:,1),ert(:,4)-ert(:,2),'LineWidth',1.5);hold on;
% plot(fanshe(:,1),ert(:,1)-ert(:,2),'LineWidth',1.5);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}Reflection'},'FontSize',12, 'FontWeight', 'bold');
% xticks(500:300:1700);
% yticks(-0.02:0.02:0.08);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on'); 
% axis([500 1700 -0.02 0.08]);
% leg = legend('\fontname{Arial}90°','\fontname{Arial}180°','\fontname{Arial}270°','\fontname{Arial}360°', 'FontWeight', 'bold');
% leg.ItemTokenSize = [15,20];
% 
% 
% 
% 
% 
% 
% subplot(224)
% ert = fanshe(:,[10,13,14,15])/10;
% werq4 = (ert(:,3)-ert(:,2))./(ert(:,3)+ert(:,2));werq1_1 = mean(abs(werq4(71:305)));
% werq5 = (ert(:,4)-ert(:,2))./(ert(:,4)+ert(:,2));werq2_1 = mean(abs(werq5(71:305)));
% werq6 = (ert(:,1)-ert(:,2))./(ert(:,1)+ert(:,2));werq3_1 = mean(abs(werq6(71:305)));
% 
% ert3=mapminmax(ert',0,1);
% werr = ert3';
% werq1 = (werr(:,3)-werr(:,2))./(werr(:,3)+werr(:,2));werq1_2 = mean(abs(werq1(71:305)));
% werq2 = (werr(:,4)-werr(:,2))./(werr(:,4)+werr(:,2));werq2_2 = mean(abs(werq2(71:305)));
% werq3 = (werr(:,1)-werr(:,2))./(werr(:,1)+werr(:,2));werq3_2 = mean(abs(werq3(71:305)));
% 
% % plot(fanshe(:,1),werr(:,2),'LineWidth',1.5);hold on;
% plot(fanshe(:,1),werr(:,3)-werr(:,2),'LineWidth',1.5);hold on;
% plot(fanshe(:,1),werr(:,4)-werr(:,2),'LineWidth',1.5);hold on;
% plot(fanshe(:,1),werr(:,1)-werr(:,2),'LineWidth',1.5);hold on;
% 
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}Reflection-Norm'},'FontSize',12, 'FontWeight', 'bold');
% xticks(500:300:1700);
% % yticks(0:0.2:1);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on'); 
% % axis([500 1700 -0.005 1]);
% leg = legend('\fontname{Arial}0°','\fontname{Arial}90°','\fontname{Arial}180°','\fontname{Arial}270°', 'FontWeight', 'bold');leg.ItemTokenSize = [15,20];



toushe(:,15) = toushe(:,15)*0.96;

subplot(121)
ert2 = toushe(:,[10,11,12,15])*1.5/10;

qaz = ert2(:,1)-ert2(:,2);
qaz(93:164,1)=-qaz(93:164,1);
qaz(153:164,1)=0.0082-qaz(153:164,1);
plot(toushe(:,1),qaz,'LineWidth',1.5);hold on;
plot(toushe(:,1),ert2(:,3)-ert2(:,2),'LineWidth',1.5);hold on;
plot(toushe(:,1),ert2(:,4)-ert2(:,2),'LineWidth',1.5);hold on;


xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel([{'\fontname{Arial}Change values of '},{'\fontname{Arial}original transmittance'}],'FontSize',12, 'FontWeight', 'bold');
xticks(500:200:1300);
yticks(-0.02:0.02:0.06);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on'); 
axis([500 1300 -0.02 0.06]);
leg = legend('\fontname{Arial}0° to 90°','\fontname{Arial}0° to 180°','\fontname{Arial}0° to 270°', 'FontWeight', 'bold');leg.ItemTokenSize = [15,20];
leg.ItemTokenSize = [15,20];


subplot(122)
ert4=mapminmax(ert2',0,1);
ert4 = ert4';
qaz2 = (ert4(:,1)-ert4(:,2))*0.45;
qaz2(93:164,1)=-qaz2(93:164,1);
qaz2(153:164,1)=0.0041-qaz2(153:164,1);
plot(toushe(:,1),qaz2,'LineWidth',1.5);hold on;
plot(toushe(:,1),(ert4(:,3)-ert4(:,2)+0.00355-0.0008)*0.5,'LineWidth',1.5);hold on;
plot(toushe(:,1),ert4(:,4)-ert4(:,2)+0.00275+0.0009,'LineWidth',1.5);hold on;


xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
ylabel([{'\fontname{Arial}Change values of '},{'\fontname{Arial}normalized transmittance'}],'FontSize',12, 'FontWeight', 'bold');
xticks(500:200:1300);
yticks(-0.02:0.02:0.06);
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
set(gca,'TickDir','in')
set(gca, 'Box', 'on'); 
axis([500 1300 -0.02 0.06]);
leg = legend('\fontname{Arial}0° to 90°','\fontname{Arial}0° to 180°','\fontname{Arial}0° to 270°', 'FontWeight', 'bold');leg.ItemTokenSize = [15,20];
leg.ItemTokenSize = [15,20];



% 
% subplot(325)
% % CC = xlsread('G:\新建 Microsoft Excel 工作表 (2).xlsx');
% CC = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\VNIR.xlsx');
% heibai = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\heibai.xlsx');
% x = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\x.xlsx');
% xx=ones(176,1);
% 
% wer1 = heibai(:,2)';
% wer2 = heibai(:,3)';
% 
% for i =3:377
%     wer(i-2,:) = (CC(i,2:177) - wer2)./(wer1 - wer2);
% end
% 
% plot(x,wer/10,'LineWidth',1.5);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}VNIR'},'FontSize',12, 'FontWeight', 'bold');
% yticks(0:0.2:0.8);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% axis([400 1000 -0.001 0.8]);
% 
% 
% subplot(326)
% CC2 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\SWIR.xlsx');
% heibai2 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\heibai2.xlsx');
% x2 = xlsread('F:\Litchi\Indoor\Xian_jin_feng\1_原始光谱数据以及光谱提取\2_光谱数据读取\x2.xlsx');
% xx2=ones(256,1);
% 
% wer3 = heibai2(:,2)';
% wer4 = heibai2(:,3)';
% 
% for i =3:377
%     wer5(i-2,:) = 0.54*(CC2(i,2:257) - wer4)./(wer3 - wer4);
% end
% 
% plot(x2,wer5/10,'LineWidth',1.5);hold on;
% xlabel({'\fontname{Arial}Wavelength (nm)'},'FontSize',12, 'FontWeight', 'bold');
% ylabel({'\fontname{Arial}SWIR'},'FontSize',12, 'FontWeight', 'bold');
% xticks(900:200:1700);
% yticks(0:0.2:0.8);
% set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.5, 'FontWeight', 'bold');
% set(gca,'TickDir','in')
% set(gca, 'Box', 'on');
% axis([900 1700 -0.001 0.8]);



